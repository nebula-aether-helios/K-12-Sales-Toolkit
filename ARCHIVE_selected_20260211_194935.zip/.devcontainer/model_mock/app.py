from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/v1/generate', methods=['POST'])
def generate():
    data = request.json or {}
    prompt = data.get('prompt', '')
    # Simple deterministic mock response
    response_text = f"[mocked response] prompt_len={len(prompt)}"
    return jsonify({
        'id': 'mock-1',
        'object': 'generation',
        'choices': [{'text': response_text}],
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
