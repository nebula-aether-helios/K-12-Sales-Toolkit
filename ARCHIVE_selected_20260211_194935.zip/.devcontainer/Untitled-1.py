"""Run this model in Python

> pip install azure-ai-inference
"""
import os
from azure.ai.inference import ChatCompletionsClient
from azure.ai.inference.models import AssistantMessage, SystemMessage, UserMessage, ToolMessage
from azure.ai.inference.models import ImageContentItem, ImageUrl, TextContentItem
from azure.core.credentials import AzureKeyCredential

client = ChatCompletionsClient(
    endpoint = "https://ai-imm09045445ai979316396441.openai.azure.com/openai/deployments/gpt-5.2-chat",
    credential = AzureKeyCredential(os.environ["AZURE_AI_API_KEY"]),
    api_version = "2025-01-01-preview",
)

messages = [
    UserMessage(content = [
        TextContentItem(text = "INSERT_INPUT_HERE"),
    ]),
]

tools = []

while True:
    response = client.complete(
        messages = messages,
        model = "gpt-5.2-chat",
        tools = tools,
    )

    if response.choices[0].message.tool_calls:
        print(response.choices[0].message.tool_calls)
        messages.append(response.choices[0].message)
        for tool_call in response.choices[0].message.tool_calls:
            messages.append(ToolMessage(
                content=locals()[tool_call.function.name](),
                tool_call_id=tool_call.id,
            ))
    else:
        print(f"[Model Response] {response.choices[0].message.content}")
        break
