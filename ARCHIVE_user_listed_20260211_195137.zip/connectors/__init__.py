"""Connectors package for ArcGIS, Wayback, DNS/MX, and ReconDon Craigslist crawler.
Each connector attempts to use real APIs if environment variables are set;
otherwise they provide a safe simulated response for local testing.
"""

from .arcgis import query_arcgis_permits
from .wayback import query_wayback_cdx
from .dns_mx import lookup_mx
from .recondon_craigslist import crawl_craigslist_by_license

__all__ = [
    "query_arcgis_permits",
    "query_wayback_cdx",
    "lookup_mx",
    "crawl_craigslist_by_license",
]
