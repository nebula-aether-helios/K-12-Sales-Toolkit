# Database enrichment snapshot — samples and gaps

Generated from the most recent full-run export: `outputs/full_database_enrichment_report.json` (generated_at: 2026-02-12T00:54:10.896030).

This document shows representative examples of: enriched rows, error rows, other/pending rows, and a concise list of important items missing from the current `PLAN`/run for full production readiness.

---

## A. Quick SQLs to extract each set

Enriched rows (per-source results exist or enrich_status='completed'):

```sql
SELECT * FROM contractors WHERE enrich_status='completed' LIMIT 5;
```

Error rows (rows with non-empty `error_message`):

```sql
SELECT license_number, business_name, address_city, enrich_status, error_message
FROM contractors
WHERE error_message IS NOT NULL
ORDER BY ROWID DESC LIMIT 50;
```

Pending / not-yet-enriched rows:

```sql
SELECT license_number, business_name, address_city, enrich_status
FROM contractors
WHERE enrich_status IN ('pending','new')
LIMIT 20;
```

DB file: `outputs/ferengi_enrichment.db` (and `outputs/enrichment.db` are present; the canonical run used above points at `outputs/ferengi_enrichment.db`).

---

## B. Representative enriched row (example)

This is a representative JSON-style extraction for a row that has been fully enriched (fields and derived triggers):

```json
{
  "license_number": "1000019",
  "business_name": "D K IRON",
  "address_city": "SACRAMENTO",
  "enrich_status": "completed",
  "gp_place_id": "ChIJ178619",
  "gp_website": "https://www.dkiron.com",
  "gp_rating": "3.7",
  "gp_review_count": "330",
  "gp_phone_verified": "0",
  "gp_lat": "38.748581",
  "gp_lng": "-121.949255",
  "osha_inspection_count": "0",
  "osha_violation_count": "0",
  "cl_ad_found": "0",
  "cl_enriched_at": "2026-02-11T06:00:30.287928",
  "trigger_fear_osha_investigation": "0",
  "trigger_envy_market_position": "0",
  "trigger_envy_competitor_permits": "0",
  "error_message": null
}
```

Source: sample rows exported to `outputs/enriched_sample_100.csv` and `outputs/enrichment_evidence_report.md`.

---

## C. Representative error row (example)

This is a row that previously raised an exception during enrichment and had the traceback persisted in `error_message`.

```json
{
  "license_number": "1000103",
  "business_name": "DNA FLOORS",
  "address_city": "CITRUS HEIGHTS",
  "enrich_status": "completed",
  "gp_place_id": null,
  "gp_website": null,
  "gp_rating": null,
  "cl_enriched_at": "2026-02-11T11:07:51.110142",
  "error_message": "Traceback (most recent call last): ... RuntimeError: GOOGLE_PLACES_API_KEY not set; cannot call Google Places"
}
```

Notes:
- Some error rows were later reprocessed successfully but retain tracebacks in `error_message` until cleared by a cleanup/smoke pass.
- The dominant recurring error observed across runs: `TypeError: '>' not supported between instances of 'NoneType' and 'float'` — caused by numeric comparisons against None in trigger logic.

---

## D. Representative pending / other row (example)

Minimal / not-enriched row (pending/new):

```json
{
  "license_number": "1002000",
  "business_name": "ACME LOCAL SERVICES",
  "address_city": "SACRAMENTO",
  "enrich_status": "new",
  "gp_place_id": null,
  "cl_ad_found": null,
  "osha_inspection_count": null,
  "error_message": null
}
```

How to find more: run the `Pending` SQL above.

---

## E. What's missing from the current PLAN / run (concise)

These items are not fully addressed by the current manifest/run and are recommended for the next work items:

- Proper defensive numeric handling and tests (safe_float) — prevents the repeated TypeError when values are null.
- Ensure `.env` or secrets are consistently loaded by the orchestrator and worker processes (missing API keys cause connector failures).
- Dead-letter queue (DLQ) + better retry/backoff for long-running/failed tasks (currently in-memory queue for local runs only).
- Rich live terminal dashboard parity with legacy `ferengi_full_enrichment.py` (per-prospect live expansion) — the new dashboard prints aggregated metrics but not the exact scrolling detail for each prospect.
- Prometheus / metrics endpoint and structured logging (for scrapers and production monitoring).
- Production-grade adapter implementations with secrets management (Google Places, DCA, OSHA remote endpoints) and unit/integration tests that mock remote calls.
- Packaging & deployment runbook (how to run as a Windows service / systemd service; environment variables provisioning).
- More exhaustive unit tests around trigger logic, string/number coercion, and adapter fingerprinting.

---

## F. Quick commands to reproduce these samples locally

Set PYTHONPATH and print top samples from DB (PowerShell):

```powershell
$env:PYTHONPATH = 'C:\Users\aether\Documents\GitHub\azuredev-2005'
# print 5 completed rows
python - <<PY
import sqlite3, json
c=sqlite3.connect('outputs/ferengi_enrichment.db')
cur=c.cursor()
for row in cur.execute("SELECT license_number,business_name,address_city,enrich_status,error_message FROM contractors WHERE enrich_status='completed' LIMIT 5"):
    print(json.dumps(dict(zip(['license','business','city','status','error'], row)), indent=2))
c.close()
PY
```

Export errored rows to CSV (PowerShell snippet):

```powershell
python - <<PY
import sqlite3,csv
conn=sqlite3.connect('outputs/ferengi_enrichment.db')
cur=conn.cursor()
cur.execute("SELECT license_number,business_name,address_city,enrich_status,error_message FROM contractors WHERE error_message IS NOT NULL")
rows=cur.fetchall()
with open('outputs/errored_rows_export.csv','w',newline='',encoding='utf-8') as fh:
  w=csv.writer(fh)
  w.writerow(['license_number','business_name','address_city','enrich_status','error_message'])
  w.writerows(rows)
conn.close()
print('Wrote outputs/errored_rows_export.csv')
PY
```

---

If you want, I can now:

- (A) Run the export above and attach `outputs/errored_rows_export.csv` to the workspace (I can generate it now), or
- (B) Apply the `safe_float` patch across trigger code and run a smoke reprocess of 200 rows.

Tell me which follow-up you prefer and I will proceed.