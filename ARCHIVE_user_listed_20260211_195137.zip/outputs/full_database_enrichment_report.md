# Ferengi Enrichment Run Analysis
Generated: 2026-02-12T00:54:10.896030

## Summary

DB path: outputs/ferengi_enrichment.db

- total rows: 9749
- completed: 7039
- errors: 465

## Top error messages (sample)

- (465) '>' not supported between instances of 'NoneType' and 'float'

## Top HTTP endpoints called

