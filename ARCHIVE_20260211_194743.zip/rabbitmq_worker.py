"""Consume enrichment jobs from RabbitMQ and process single prospects using existing Ferengi class.
This worker imports `FerengiFullDatabaseEnrichment` from the main runner and runs `enrich_single_prospect` and `update_database` per message.
"""
import os
import json
import pika
import sqlite3
from time import sleep

RABBITMQ_URL = os.getenv("RABBITMQ_URL")
QUEUE_NAME = os.getenv("RABBITMQ_QUEUE", "ferengi_enrich_jobs")
DB_PATH = os.getenv("FERENGI_DB", "./outputs/ferengi_enrichment.db")


def process_message(body, enricher):
    try:
        data = json.loads(body)
        license_number = data.get("license_number")
        if not license_number:
            print("Invalid message, no license_number")
            return

        # fetch prospect row
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT * FROM contractors WHERE license_number = ?", (license_number,))
        cols = [c[0] for c in cur.description] if cur.description else []
        row = cur.fetchone()
        conn.close()

        if not row:
            print("No prospect found for", license_number)
            return

        prospect = dict(zip(cols, row))
        result = enricher.enrich_single_prospect(prospect)
        enricher.update_database(result)
    except Exception as e:
        print("Worker error:", e)


def run_worker():
    if not RABBITMQ_URL:
        print("RABBITMQ_URL not set; worker will not start.")
        return

    from ferengi_full_enrichment import FerengiFullDatabaseEnrichment

    enricher = FerengiFullDatabaseEnrichment(db_path=DB_PATH, workers=1)

    params = pika.URLParameters(RABBITMQ_URL)
    conn = pika.BlockingConnection(params)
    ch = conn.channel()
    ch.queue_declare(queue=QUEUE_NAME, durable=True)

    def callback(ch, method, properties, body):
        process_message(body, enricher)
        ch.basic_ack(delivery_tag=method.delivery_tag)

    ch.basic_qos(prefetch_count=1)
    ch.basic_consume(queue=QUEUE_NAME, on_message_callback=callback)
    print("[*] Waiting for messages. To exit press CTRL+C")
    try:
        ch.start_consuming()
    except KeyboardInterrupt:
        ch.stop_consuming()
    conn.close()


if __name__ == '__main__':
    run_worker()
