"""
Enrichment pipeline runner (real adapters, fail-fast) for 10-prospect sample.
Sources: Google Places, OSHA, ArcGIS permits, Craigslist (Recondon), OSINT/DNS.
Outputs: outputs/enrichment_run_10.json and outputs/enrichment_run_10.csv
Environment variables:
  GOOGLE_PLACES_API_KEY
  OSHA_APP_TOKEN (optional)
  ARC_GIS_TOKEN (optional)
Runtime expectations: external network required; adapters log failures clearly.
"""
from __future__ import annotations
import asyncio
import aiohttp
import json
import os
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import pandas as pd
import requests
# --------------------------- config ---------------------------
CSV_PATH = Path("sacramento_contractors_cslb_sac.csv")
OUTPUTS_DIR = Path("outputs")
SAMPLE_SIZE = 10
GOOGLE_TIMEOUT = 10
OSHA_TIMEOUT = 10
ARCGIS_TIMEOUT = 10
CRAWLER_PAGES = 1  # keep light for fail-fast
CRAWLER_CONCURRENCY = 3
HEADERS = {"User-Agent": "Mozilla/5.0 (enrichment-runner)"}
# --------------------------- data models ---------------------------
@dataclass
class Prospect:
    license_number: str
    business_name: str
    address_city: str
    address_state: str
    address_zip: str

@dataclass
class EnrichmentResult:
    license_number: str
    gp: Dict[str, Any]
    osha: Dict[str, Any]
    permits: Dict[str, Any]
    craigslist: Dict[str, Any]
    osint: Dict[str, Any]
    errors: List[str]
# --------------------------- helpers ---------------------------
def load_sample(n: int = SAMPLE_SIZE) -> List[Prospect]:
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH, nrows=n)
    required = ["license_number", "business_name", "address_city", "address_state", "address_zip"]
    for col in required:
        if col not in df.columns:
            raise KeyError(f"Missing column: {col}")
    sample = []
    for _, row in df.iterrows():
        sample.append(
            Prospect(
                license_number=str(row["license_number"]),
                business_name=str(row["business_name"]),
                address_city=str(row["address_city"]),
                address_state=str(row["address_state"]),
                address_zip=str(row["address_zip"]),
            )
        )
    return sample
# --------------------------- adapters ---------------------------
async def fetch_google_places(session: aiohttp.ClientSession, p: Prospect) -> Dict[str, Any]:
    key = os.getenv("GOOGLE_PLACES_API_KEY")
    if not key:
        return {"status": "skipped", "reason": "GOOGLE_PLACES_API_KEY missing"}
    query = f"{p.business_name} {p.address_city} {p.address_state} {p.address_zip}"
    url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
    params = {"query": query, "key": key}
    try:
        async with session.get(url, params=params, headers=HEADERS, timeout=GOOGLE_TIMEOUT) as resp:
            data = await resp.json()
            if data.get("status") != "OK":
                return {"status": "error", "google_status": data.get("status"), "error_message": data.get("error_message")}
            first = data.get("results", [{}])[0]
            return {
                "status": "ok",
                "place_id": first.get("place_id"),
                "rating": first.get("rating"),
                "review_count": first.get("user_ratings_total"),
                "lat": first.get("geometry", {}).get("location", {}).get("lat"),
                "lng": first.get("geometry", {}).get("location", {}).get("lng"),
                "types": first.get("types"),
                "formatted_address": first.get("formatted_address"),
            }
    except Exception as e:  # noqa: BLE001
        return {"status": "error", "exception": str(e)}

async def fetch_osha(session: aiohttp.ClientSession, p: Prospect) -> Dict[str, Any]:
    # OSHA API surface is unstable; this uses a basic DDG JSON search as a fallback signal.
    query = f"OSHA {p.business_name} {p.address_state} enforcement"
    url = "https://duckduckgo.com/html/"
    params = {"q": query}
    try:
        async with session.get(url, params=params, headers=HEADERS, timeout=OSHA_TIMEOUT) as resp:
            txt = await resp.text()
            hit = "osha" in txt.lower()
            return {"status": "ok", "has_hits": hit, "signal": "ddg_html_search"}
    except Exception as e:  # noqa: BLE001
        return {"status": "error", "exception": str(e)}

async def fetch_arcgis_permits(session: aiohttp.ClientSession, p: Prospect) -> Dict[str, Any]:
    # Sacramento Building Permits layer (public). Field names may evolve; this is best-effort.
    base = "https://services.arcgis.com/8CpMUd3fdw6aXef7/ArcGIS/rest/services/Building_Permits/FeatureServer/0/query"
    where = f"Contractor LIKE '%{p.business_name.replace("'", "''")}%'"
    params = {
        "where": where,
        "outFields": "PermitType,AppliedDate,IssuedDate,FinaledDate,Valuation,Contractor",
        "f": "json",
        "resultRecordCount": 5,
    }
    try:
        async with session.get(base, params=params, headers=HEADERS, timeout=ARCGIS_TIMEOUT) as resp:
            data = await resp.json()
            feats = data.get("features", [])
            if not feats:
                return {"status": "none"}
            agg_val = sum((f.get("attributes", {}).get("Valuation") or 0) for f in feats)
            last_issue = max((f.get("attributes", {}).get("IssuedDate") or 0) for f in feats)
            types = list({f.get("attributes", {}).get("PermitType") for f in feats if f.get("attributes")})
            return {"status": "ok", "count": len(feats), "valuation_sum": agg_val, "last_issued": last_issue, "types": types}
    except Exception as e:  # noqa: BLE001
        return {"status": "error", "exception": str(e)}

# Minimal RECONDON crawler (trimmed, no BERT to avoid heavy downloads).
class MiniRecondon:
    def __init__(self, regions: List[str], categories: List[str], max_pages: int = 1, concurrency: int = 3):
        self.regions = regions
        self.categories = categories
        self.max_pages = max_pages
        self.semaphore = asyncio.Semaphore(concurrency)
        self.results: List[Dict[str, Any]] = []
        self.seen: set[str] = set()

    async def crawl(self) -> List[Dict[str, Any]]:
        connector = aiohttp.TCPConnector(limit=10)
        async with aiohttp.ClientSession(connector=connector, headers=HEADERS) as session:
            listing_urls: List[str] = []
            for region in self.regions:
                for cat in self.categories:
                    for page in range(self.max_pages):
                        url = f"https://{region}.craigslist.org/search/{cat}?s={page*120}"
                        html = await self._fetch(session, url)
                        if not html:
                            continue
                        for link in html.split('href="'):
                            if "craigslist.org" in link and "html" in link:
                                href = link.split('"')[0]
                                if href.startswith("/" ):
                                    href = f"https://{region}.craigslist.org{href}"
                                listing_urls.append(href)
            for url in set(listing_urls[:50]):  # cap for speed
                html = await self._fetch(session, url)
                if not html:
                    continue
                self._parse(html, url)
        return self.results

    async def _fetch(self, session: aiohttp.ClientSession, url: str) -> Optional[str]:
        async with self.semaphore:
            try:
                async with session.get(url, timeout=10) as resp:
                    if resp.status == 200:
                        return await resp.text()
            except Exception:
                return None
        return None

    def _parse(self, html: str, url: str) -> None:
        title = extract_between(html, "title>", "</title>") or ""
        desc = extract_between(html, "<section id=\"postingbody\">", "</section>") or ""
        fp = f"{url.split('/')[-1]}:{hash(desc) % 10_000_000}"
        if fp in self.seen:
            return
        self.seen.add(fp)
        down_payment_violation = "10%" in desc or "$1000" in desc
        self.results.append(
            {
                "url": url,
                "title": title.strip(),
                "down_payment_violation": down_payment_violation,
                "ad_found": True,
                "fingerprint": fp,
            }
        )

def extract_between(text: str, start: str, end: str) -> Optional[str]:
    if start not in text or end not in text:
        return None
    try:
        return text.split(start, 1)[1].split(end, 1)[0]
    except Exception:
        return None

async def fetch_craigslist() -> List[Dict[str, Any]]:
    crawler = MiniRecondon(["sacramento"], ["sss", "cto"], max_pages=CRAWLER_PAGES, concurrency=CRAWLER_CONCURRENCY)
    return await crawler.crawl()

def osint_dns_probe(p: Prospect) -> Dict[str, Any]:
    # Lightweight DNS/website derivation based on ozzyOsint skeleton
    domain = derive_domain_from_name(p.business_name)
    return {
        "status": "ok",
        "derived_domain": domain,
    }

def derive_domain_from_name(name: str) -> str:
    clean = "".join(ch for ch in name if ch.isalnum()).lower()
    if not clean:
        return ""
    return f"{clean}.com"
# --------------------------- pipeline ---------------------------
async def enrich_prospect(session: aiohttp.ClientSession, p: Prospect, craigslist_cache: List[Dict[str, Any]]) -> EnrichmentResult:
    errors: List[str] = []
    gp = await fetch_google_places(session, p)
    if gp.get("status") == "error":
        errors.append(f"google:{gp}")
    osha = await fetch_osha(session, p)
    if osha.get("status") == "error":
        errors.append(f"osha:{osha}")
    permits = await fetch_arcgis_permits(session, p)
    if permits.get("status") == "error":
        errors.append(f"arcgis:{permits}")
    # craigslist: match any listing that mentions business name
    matches = [c for c in craigslist_cache if p.business_name.lower()[:10] in c.get("title", "").lower()]
    cl = matches[0] if matches else ({"status": "none"} if craigslist_cache else {"status": "error", "reason": "crawler_failed"})
    osint = osint_dns_probe(p)
    return EnrichmentResult(
        license_number=p.license_number,
        gp=gp,
        osha=osha,
        permits=permits,
        craigslist=cl,
        osint=osint,
        errors=errors,
    )

async def main() -> None:
    OUTPUTS_DIR.mkdir(exist_ok=True)
    prospects = load_sample(SAMPLE_SIZE)
    async with aiohttp.ClientSession(headers=HEADERS) as session:
        # run crawler once and reuse results to avoid hammering
        try:
            craigslist_cache = await fetch_craigslist()
        except Exception as e:  # noqa: BLE001
            craigslist_cache = []
            print(f"Craigslist crawler failed: {e}")
        tasks = [enrich_prospect(session, p, craigslist_cache) for p in prospects]
        results = await asyncio.gather(*tasks)
    # serialize
    ts = datetime.utcnow().isoformat()
    json_path = OUTPUTS_DIR / "enrichment_run_10.json"
    csv_path = OUTPUTS_DIR / "enrichment_run_10.csv"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({"timestamp": ts, "results": [asdict(r) for r in results]}, f, indent=2)
    rows = []
    for r in results:
        row = {
            "license_number": r.license_number,
            "gp_status": r.gp.get("status"),
            "gp_rating": r.gp.get("rating"),
            "osha_hits": r.osha.get("has_hits"),
            "permit_count": r.permits.get("count"),
            "cl_status": r.craigslist.get("status"),
            "cl_violation": r.craigslist.get("down_payment_violation"),
            "derived_domain": r.osint.get("derived_domain"),
            "errors": ";".join(r.errors),
        }
        rows.append(row)
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    print(f"✅ Enrichment run complete @ {ts}")
    print(f"   JSON: {json_path}")
    print(f"   CSV:  {csv_path}")

if __name__ == "__main__":
    asyncio.run(main())
