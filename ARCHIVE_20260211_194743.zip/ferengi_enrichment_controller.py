#!/usr/bin/env python3
"""
ferengi_enrichment_controller.py

Simple controller to run the enricher recursively until completion goals are met.

Usage: python3 ferengi_enrichment_controller.py --db ./outputs/ferengi_enrichment.db

This script will repeatedly invoke `ferengi_full_enrichment.py` in the workspace and
recompute completion statistics, stopping when completion_rate >= target or when
manually interrupted.

It also supports an environment variable RECORD_HTTP=1 to instruct the enricher
to persist raw HTTP responses (if the enricher supports that flag).
"""
import argparse
import json
import shutil
import subprocess
import sys
import time
import sqlite3
from datetime import datetime


def read_counts(db_path):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM contractors")
    total = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM contractors WHERE enrich_status='completed'")
    completed = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM contractors WHERE error_message IS NOT NULL AND TRIM(error_message)<>''")
    errors = cur.fetchone()[0]
    conn.close()
    return {'total': total, 'completed': completed, 'errors': errors}


def run_enricher(db_path, extra_args=None):
    cmd = [sys.executable, 'ferengi_full_enrichment.py', '--db', db_path]
    if extra_args:
        cmd += extra_args
    env = dict(**dict(**__import__('os').environ))
    # Respect RECORD_HTTP env var if set
    if env.get('RECORD_HTTP'):
        print('RECORD_HTTP enabled: enricher should record HTTP responses to ./outputs/responses/')
    print('Running enricher:', ' '.join(cmd))
    p = subprocess.run(cmd, env=env)
    return p.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True, help='Path to SQLite DB')
    parser.add_argument('--target', type=float, default=99.9, help='Target completion rate (percent)')
    parser.add_argument('--max-iterations', type=int, default=0, help='0 = unlimited')
    parser.add_argument('--pause-seconds', type=int, default=10, help='Seconds between iterations')
    args = parser.parse_args()

    iterations = 0
    start_time = datetime.utcnow()
    while True:
        iterations += 1
        print(f"\n[{datetime.utcnow().isoformat()}] Starting iteration {iterations}")
        rc = run_enricher(args.db)
        counts = read_counts(args.db)
        total = counts['total'] or 1
        completed = counts['completed']
        errors = counts['errors']
        completion_rate = completed / total * 100.0
        print(f"Iteration {iterations} complete: {completed}/{total} ({completion_rate:.3f}%), errors={errors}")

        # save progress snapshot
        snapshot = {
            'iteration': iterations,
            'timestamp': datetime.utcnow().isoformat(),
            'counts': counts,
            'return_code': rc
        }
        with open('outputs/recursive_snapshot_{:03d}.json'.format(iterations), 'w', encoding='utf-8') as f:
            json.dump(snapshot, f, indent=2)

        if completion_rate >= args.target:
            print(f"Target reached: {completion_rate:.3f}% >= {args.target}% — stopping.")
            break
        if args.max_iterations and iterations >= args.max_iterations:
            print('Max iterations reached; stopping.')
            break
        print(f"Sleeping {args.pause_seconds}s before next iteration...")
        try:
            time.sleep(args.pause_seconds)
        except KeyboardInterrupt:
            print('Interrupted by user; exiting.')
            break

    elapsed = datetime.utcnow() - start_time
    print(f"Done. Iterations={iterations} elapsed={elapsed}")


if __name__ == '__main__':
    main()
