"""
Deep OSINT Enrichment Module - FREE Proprietary Tools
Uses: DNS resolution, MX validation, phone parsing, domain derivation, dorking patterns
No paid APIs required - all functionality via standard libraries + free services
"""
from __future__ import annotations
import asyncio
import aiohttp
import re
import socket
import hashlib
import json
import os
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus
import pandas as pd

# DNS/MX
try:
    import dns.resolver
    DNS_AVAILABLE = True
except ImportError:
    DNS_AVAILABLE = False

# Phone parsing
try:
    import phonenumbers
    from phonenumbers import carrier, geocoder, timezone as pn_tz
    PHONE_AVAILABLE = True
except ImportError:
    PHONE_AVAILABLE = False

# ============================================================================
# CONFIGURATION
# ============================================================================
CSV_PATH = Path("sacramento_contractors_cslb_sac.csv")
OUTPUTS_DIR = Path("outputs")
SAMPLE_SIZE = 10
HEADERS = {"User-Agent": "Mozilla/5.0 (OSINT-Enrichment-Pipeline/1.0)"}
TIMEOUT = 10

# ============================================================================
# DATA MODELS
# ============================================================================
@dataclass
class Prospect:
    license_number: str
    business_name: str
    address_city: str
    address_state: str
    address_zip: str
    phone_business: str = ""
    dba_name: str = ""

@dataclass
class OSINTResult:
    license_number: str
    # MX/DNS
    derived_domain: str = ""
    domain_has_mx: bool = False
    domain_has_a: bool = False
    mx_records: List[str] = field(default_factory=list)
    dns_score: int = 0
    # Phone
    phone_valid: bool = False
    phone_country: str = ""
    phone_carrier: str = ""
    phone_type: str = ""  # MOBILE, FIXED_LINE, VOIP, etc
    phone_region: str = ""
    # Craigslist/RECONDON
    cl_ad_found: bool = False
    cl_ad_url: str = ""
    cl_license_displayed: bool = False
    cl_down_payment_violation: bool = False
    cl_fingerprint: str = ""
    # Dorking signals
    dork_osha_hits: int = 0
    dork_court_hits: int = 0
    dork_bbb_hits: int = 0
    dork_yelp_hits: int = 0
    # Triggers (per v3 primal framework)
    trigger_fear_osha_investigation: bool = False
    trigger_fear_craigslist_violation: bool = False
    trigger_envy_competitor_permits: bool = False
    # Meta
    enrichment_ts: str = ""
    errors: List[str] = field(default_factory=list)

# ============================================================================
# OSINT FUNCTIONS - FREE/PROPRIETARY
# ============================================================================

def derive_domain(business_name: str) -> str:
    """Derive likely .com domain from business name."""
    clean = re.sub(r'[^a-zA-Z0-9]', '', business_name).lower()
    return f"{clean}.com" if clean else ""

def check_dns_a(domain: str) -> bool:
    """Check if domain has A record (website likely exists)."""
    if not DNS_AVAILABLE or not domain:
        return False
    try:
        dns.resolver.resolve(domain, 'A', lifetime=3)
        return True
    except Exception:
        return False

def get_mx_records(domain: str) -> Tuple[bool, List[str]]:
    """Get MX records for domain (email capability)."""
    if not DNS_AVAILABLE or not domain:
        return False, []
    try:
        answers = dns.resolver.resolve(domain, 'MX', lifetime=3)
        records = [str(r.exchange).rstrip('.') for r in answers]
        return bool(records), records
    except Exception:
        return False, []

def calculate_dns_score(has_a: bool, has_mx: bool, mx_count: int) -> int:
    """Score domain based on DNS presence (0-100)."""
    score = 0
    if has_a:
        score += 40
    if has_mx:
        score += 40
        score += min(mx_count * 5, 20)  # bonus for multiple MX
    return score

def parse_phone(phone: str) -> Dict[str, Any]:
    """Parse phone number for carrier, type, region using phonenumbers lib."""
    result = {
        "valid": False,
        "country": "",
        "carrier": "",
        "type": "",
        "region": "",
    }
    if not PHONE_AVAILABLE or not phone:
        return result
    try:
        # Try US format first
        clean = re.sub(r'\D', '', phone)
        if len(clean) == 10:
            clean = '1' + clean
        parsed = phonenumbers.parse('+' + clean, None)
        if phonenumbers.is_valid_number(parsed):
            result["valid"] = True
            result["country"] = phonenumbers.region_code_for_number(parsed) or ""
            result["carrier"] = carrier.name_for_number(parsed, "en") or ""
            num_type = phonenumbers.number_type(parsed)
            type_map = {0: "FIXED_LINE", 1: "MOBILE", 2: "FIXED_OR_MOBILE", 3: "TOLL_FREE", 4: "PREMIUM", 5: "SHARED_COST", 6: "VOIP", 7: "PERSONAL", 8: "PAGER", 9: "UAN", 10: "VOICEMAIL"}
            result["type"] = type_map.get(num_type, "UNKNOWN")
            result["region"] = geocoder.description_for_number(parsed, "en") or ""
    except Exception:
        pass
    return result

# ============================================================================
# CRAIGSLIST/RECONDON CRAWLER (License-aware)
# ============================================================================

class RecondonLicenseCrawler:
    """Async Craigslist crawler that searches for contractor license numbers."""
    
    def __init__(self, regions: List[str], categories: List[str], max_pages: int = 1, concurrency: int = 3):
        self.regions = regions
        self.categories = categories
        self.max_pages = max_pages
        self.semaphore = asyncio.Semaphore(concurrency)
        self.listings: List[Dict[str, Any]] = []
        self.seen: set = set()

    async def crawl(self) -> List[Dict[str, Any]]:
        connector = aiohttp.TCPConnector(limit=10)
        async with aiohttp.ClientSession(connector=connector, headers=HEADERS) as session:
            listing_urls: List[str] = []
            for region in self.regions:
                for cat in self.categories:
                    for page in range(self.max_pages):
                        url = f"https://{region}.craigslist.org/search/{cat}?s={page*120}"
                        html = await self._fetch(session, url)
                        if not html:
                            continue
                        # Extract listing URLs
                        for match in re.findall(r'href="(https://[^"]+\.html)"', html):
                            if 'craigslist.org' in match:
                                listing_urls.append(match)
            # Fetch individual listings (cap for speed)
            for url in list(set(listing_urls))[:100]:
                html = await self._fetch(session, url)
                if html:
                    self._parse_listing(html, url)
        return self.listings

    async def _fetch(self, session: aiohttp.ClientSession, url: str) -> Optional[str]:
        async with self.semaphore:
            try:
                async with session.get(url, timeout=TIMEOUT) as resp:
                    if resp.status == 200:
                        return await resp.text()
            except Exception:
                pass
        return None

    def _parse_listing(self, html: str, url: str) -> None:
        # Extract title
        title_match = re.search(r'<title>([^<]+)</title>', html)
        title = title_match.group(1).strip() if title_match else ""
        # Extract body
        body_match = re.search(r'<section id="postingbody">(.*?)</section>', html, re.DOTALL)
        body = re.sub(r'<[^>]+>', '', body_match.group(1)) if body_match else ""
        full_text = f"{title} {body}".lower()
        # Fingerprint
        fp = hashlib.sha256(f"{url}:{full_text[:200]}".encode()).hexdigest()[:16]
        if fp in self.seen:
            return
        self.seen.add(fp)
        # Detect license numbers (7-digit pattern common for CSLB)
        license_matches = re.findall(r'\b\d{6,8}\b', full_text)
        # Down payment violation detection (10%/$1000 rule)
        down_payment_violation = bool(re.search(r'(10%|10 percent|\$1000|1000 down|deposit)', full_text, re.I))
        self.listings.append({
            "url": url,
            "title": title,
            "body_snippet": body[:500],
            "license_numbers_found": license_matches,
            "down_payment_violation": down_payment_violation,
            "fingerprint": fp,
        })

    def match_license(self, license_number: str) -> Optional[Dict[str, Any]]:
        """Find listing that mentions this license number."""
        for listing in self.listings:
            if license_number in listing.get("license_numbers_found", []):
                return listing
        return None

    def match_business_name(self, business_name: str) -> Optional[Dict[str, Any]]:
        """Find listing that mentions this business name."""
        clean_name = business_name.lower()[:15]
        for listing in self.listings:
            if clean_name in listing.get("title", "").lower() or clean_name in listing.get("body_snippet", "").lower():
                return listing
        return None

# ============================================================================
# DORKING (DDG HTML - no API needed)
# ============================================================================

async def dork_search(session: aiohttp.ClientSession, query: str) -> int:
    """Search DuckDuckGo HTML for hit count (free, no API)."""
    url = "https://duckduckgo.com/html/"
    params = {"q": query}
    try:
        async with session.get(url, params=params, headers=HEADERS, timeout=TIMEOUT) as resp:
            html = await resp.text()
            # Count result divs
            hits = html.lower().count('class="result')
            return hits
    except Exception:
        return 0

async def run_dorks(session: aiohttp.ClientSession, business_name: str, state: str = "CA") -> Dict[str, int]:
    """Run OSINT dorks for OSHA, court, BBB, Yelp signals."""
    results = {}
    dorks = {
        "osha": f'site:osha.gov "{business_name}" {state}',
        "court": f'site:courtlistener.com "{business_name}"',
        "bbb": f'site:bbb.org "{business_name}"',
        "yelp": f'site:yelp.com "{business_name}" {state}',
    }
    for key, query in dorks.items():
        results[key] = await dork_search(session, query)
        await asyncio.sleep(0.5)  # rate limit
    return results

# ============================================================================
# ORCHESTRATOR
# ============================================================================

def load_sample(n: int = SAMPLE_SIZE) -> List[Prospect]:
    if not CSV_PATH.exists():
        raise FileNotFoundError(f"CSV not found: {CSV_PATH}")
    df = pd.read_csv(CSV_PATH, nrows=n)
    sample = []
    for _, row in df.iterrows():
        sample.append(Prospect(
            license_number=str(row.get("license_number", "")),
            business_name=str(row.get("business_name", "")),
            address_city=str(row.get("address_city", "")),
            address_state=str(row.get("address_state", "")),
            address_zip=str(row.get("address_zip", "")),
            phone_business=str(row.get("phone_business", "")),
            dba_name=str(row.get("dba_name", "")),
        ))
    return sample

async def enrich_prospect(session: aiohttp.ClientSession, p: Prospect, cl_cache: List[Dict[str, Any]]) -> OSINTResult:
    errors: List[str] = []
    result = OSINTResult(license_number=p.license_number)
    
    # 1. Domain derivation + DNS/MX
    domain = derive_domain(p.business_name)
    result.derived_domain = domain
    if domain:
        result.domain_has_a = check_dns_a(domain)
        result.domain_has_mx, result.mx_records = get_mx_records(domain)
        result.dns_score = calculate_dns_score(result.domain_has_a, result.domain_has_mx, len(result.mx_records))
    
    # 2. Phone parsing
    if p.phone_business:
        phone_info = parse_phone(p.phone_business)
        result.phone_valid = phone_info["valid"]
        result.phone_country = phone_info["country"]
        result.phone_carrier = phone_info["carrier"]
        result.phone_type = phone_info["type"]
        result.phone_region = phone_info["region"]
    
    # 3. Craigslist match (by license then by name)
    cl_match = None
    for listing in cl_cache:
        if p.license_number in listing.get("license_numbers_found", []):
            cl_match = listing
            result.cl_license_displayed = True
            break
    if not cl_match:
        clean_name = p.business_name.lower()[:15]
        for listing in cl_cache:
            if clean_name in listing.get("title", "").lower() or clean_name in listing.get("body_snippet", "").lower():
                cl_match = listing
                break
    if cl_match:
        result.cl_ad_found = True
        result.cl_ad_url = cl_match.get("url", "")
        result.cl_down_payment_violation = cl_match.get("down_payment_violation", False)
        result.cl_fingerprint = cl_match.get("fingerprint", "")
        if result.cl_down_payment_violation:
            result.trigger_fear_craigslist_violation = True
    
    # 4. Dorking
    try:
        dork_results = await run_dorks(session, p.business_name, p.address_state)
        result.dork_osha_hits = dork_results.get("osha", 0)
        result.dork_court_hits = dork_results.get("court", 0)
        result.dork_bbb_hits = dork_results.get("bbb", 0)
        result.dork_yelp_hits = dork_results.get("yelp", 0)
        if result.dork_osha_hits > 0:
            result.trigger_fear_osha_investigation = True
    except Exception as e:
        errors.append(f"dork:{e}")
    
    result.enrichment_ts = datetime.now(timezone.utc).isoformat()
    result.errors = errors
    return result

async def run_deep_enrichment(sample_size: int = SAMPLE_SIZE) -> List[OSINTResult]:
    OUTPUTS_DIR.mkdir(exist_ok=True)
    prospects = load_sample(sample_size)
    print(f"🔍 Loaded {len(prospects)} prospects for deep OSINT enrichment")
    
    # Run Craigslist crawler once
    print("🕸️ Running RECONDON Craigslist crawler (sacramento)...")
    crawler = RecondonLicenseCrawler(["sacramento"], ["sss", "cto", "bfs"], max_pages=1, concurrency=3)
    async with aiohttp.ClientSession(headers=HEADERS) as session:
        try:
            cl_cache = await crawler.crawl()
            print(f"   ✅ Crawled {len(cl_cache)} listings, found {sum(len(l.get('license_numbers_found', [])) for l in cl_cache)} license mentions")
        except Exception as e:
            cl_cache = []
            print(f"   ❌ Crawler failed: {e}")
        
        # Enrich each prospect
        print("🔬 Running deep OSINT on each prospect...")
        results = []
        for i, p in enumerate(prospects):
            r = await enrich_prospect(session, p, cl_cache)
            results.append(r)
            status = "✅" if r.dns_score > 0 or r.phone_valid or r.cl_ad_found else "⚪"
            print(f"   {status} [{i+1}/{len(prospects)}] {p.license_number} - DNS:{r.dns_score} Phone:{r.phone_valid} CL:{r.cl_ad_found}")
    
    # Save outputs
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    json_path = OUTPUTS_DIR / f"deep_osint_{ts}.json"
    csv_path = OUTPUTS_DIR / f"deep_osint_{ts}.csv"
    with open(json_path, "w") as f:
        json.dump({"timestamp": ts, "count": len(results), "results": [asdict(r) for r in results]}, f, indent=2)
    rows = [asdict(r) for r in results]
    pd.DataFrame(rows).to_csv(csv_path, index=False)
    print(f"\n✅ Deep OSINT enrichment complete!")
    print(f"   JSON: {json_path}")
    print(f"   CSV:  {csv_path}")
    return results

if __name__ == "__main__":
    asyncio.run(run_deep_enrichment(SAMPLE_SIZE))
