#!/usr/bin/env python3
"""
Ferengi Master Catalog creator

Generates `./outputs/ferengi_master_catalog.json` and
`./outputs/ferengi_catalog_summary.json` describing API endpoints,
credentials, and acquisition protocols.
"""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict


class FerengiMasterCatalog:
    def __init__(self):
        self.catalog = {
            "catalog_metadata": {
                "catalog_id": f"FMC-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
                "created_by": "Ferengi Commerce Authority",
                "creation_date": datetime.now().isoformat(),
                "version": "2.0.0",
                "rules_of_acquisition": [
                    "Rule #10: Greed is eternal - Catalog every data source",
                    "Rule #125: You can't make a deal if you can't make contact - Complete documentation",
                    "Rule #34: War is good for business - Superior intelligence through data"
                ]
            },
            "api_categories": {},
            "endpoint_registry": {},
            "authentication_methods": {},
            "data_acquisition_protocols": {},
            "quality_standards": {}
        }
        self.env_credentials = self.load_environment_credentials()

    def load_environment_credentials(self):
        creds = {}
        creds["google_places"] = {
            "api_key": os.getenv("GOOGLE_PLACES"),
            "backup_key": os.getenv("GOOGLE_API_CLOUD"),
            "status": "AVAILABLE" if os.getenv("GOOGLE_PLACES") or os.getenv("GOOGLE_API_CLOUD") else "MISSING",
        }
        creds["us_dept_labor"] = {
            "api_key": os.getenv("US_DEPT_OF_LABOR_API"),
            "status": "AVAILABLE" if os.getenv("US_DEPT_OF_LABOR_API") else "MISSING",
        }
        creds["arcgis_sacramento"] = {
            "credentials": os.getenv("ERIS_ARCGIS_GEOHUB"),
            "status": "AVAILABLE" if os.getenv("ERIS_ARCGIS_GEOHUB") else "MISSING",
        }
        creds["rabbitmq"] = {
            "url": os.getenv("RABBITMQ_URL"),
            "management_url": os.getenv("RABBITMQ_MANAGEMENT_URL"),
            "status": "AVAILABLE" if os.getenv("RABBITMQ_URL") else "MISSING",
        }
        creds["mongodb"] = {
            "uri": os.getenv("MONGODB_URI"),
            "status": "AVAILABLE" if os.getenv("MONGODB_URI") else "MISSING",
        }
        return creds

    def load_source_manifests(self):
        """Load local source manifests from catalog_api/sources and include physical datasets."""
        src_dir = Path('catalog_api') / 'sources'
        dsets = {}
        if not src_dir.exists():
            return dsets
        for p in src_dir.glob('*.json'):
            try:
                j = json.loads(p.read_text(encoding='utf-8'))
            except Exception:
                continue
            name = j.get('name') or p.stem
            dsets[name] = {
                'manifest_path': str(p),
                'type': j.get('type'),
                'source_urls': j.get('source_urls'),
                'example_files': j.get('example_files')
            }
        self.catalog['dca_physical_datasets'] = dsets
        return dsets

    def create_api_categories(self):
        self.catalog["api_categories"] = {
            "government_data": {
                "description": "Official government data sources",
                "priority": "CRITICAL",
                "apis": ["osha_dol", "arcgis_sacramento", "cslb_licensing", "sos_business_search"],
            },
            "business_intelligence": {
                "description": "Commercial business data and intelligence",
                "priority": "HIGH",
                "apis": ["google_places", "yelp_fusion", "bbb_api", "duns_bradstreet"],
            },
            "web_intelligence": {
                "description": "Web scraping and OSINT sources",
                "priority": "HIGH",
                "apis": ["craigslist_scraper", "wayback_machine", "duckduckgo_search", "social_media_osint"],
            },
            "infrastructure_services": {
                "description": "Supporting infrastructure and messaging",
                "priority": "MEDIUM",
                "apis": ["rabbitmq", "mongodb", "redis_cache", "elasticsearch"],
            },
            "validation_services": {
                "description": "Data validation and verification",
                "priority": "MEDIUM",
                "apis": ["dns_validation", "phone_validation", "email_verification", "address_standardization"],
            }
        }

    def create_endpoint_registry(self):
        self.catalog["endpoint_registry"] = {
            "google_places_api": {
                "category": "business_intelligence",
                "status": "PRODUCTION_READY",
                "authentication": "API_KEY",
                "base_url": "https://places.googleapis.com",
                "endpoints": {
                    "text_search": {
                        "url": "/v1/places:searchText",
                        "method": "POST",
                        "parameters": {"textQuery": {}, "fields": {}, "locationBias": {}},
                        "response_fields": ["id", "displayName", "formattedAddress", "rating", "userRatingCount", "websiteUri", "nationalPhoneNumber"],
                        "rate_limit": "100 requests/minute"
                    },
                    "place_details": {
                        "url": "/v1/places/{place_id}",
                        "method": "GET",
                        "parameters": {"place_id": {}, "fields": {}},
                        "response_fields": ["businessStatus", "priceLevel", "reviews", "photos", "openingHours"],
                        "rate_limit": "100 requests/minute"
                    },
                    "legacy_text_search": {
                        "url": "https://maps.googleapis.com/maps/api/place/textsearch/json",
                        "method": "GET"
                    }
                }
            },
            "osha_dol_api": {
                "category": "government_data",
                "status": "PRODUCTION_READY",
                "authentication": "API_KEY",
                "base_url": "https://api.dol.gov",
                "endpoints": {"inspections": {"url": "https://enforcedata.dol.gov/api/osha_inspection", "method": "GET"}}
            },
            "arcgis_sacramento": {
                "category": "government_data",
                "status": "PRODUCTION_READY",
                "authentication": "BASIC_AUTH",
                "base_url": "https://services.arcgis.com/S8zZg9pg23JUEexQ/arcgis/rest/services",
            },
            "wayback_machine_cdx": {
                "category": "web_intelligence",
                "status": "PRODUCTION_READY",
                "authentication": "NONE",
                "base_url": "https://web.archive.org",
            },
            "craigslist_scraper": {
                "category": "web_intelligence",
                "status": "PRODUCTION_READY",
                "authentication": "NONE",
                "base_url": "https://sacramento.craigslist.org",
            }
        }

    def create_authentication_methods(self):
        self.catalog["authentication_methods"] = {
            "api_key": {"description": "API key in header or query"},
            "basic_auth": {"description": "Basic auth"},
            "oauth2": {"description": "OAuth2 token"},
            "none": {"description": "No auth"}
        }

    def create_data_acquisition_protocols(self):
        self.catalog["data_acquisition_protocols"] = {
            "batch_processing": {"batch_sizes": {"google_places": 50, "osha_dol": 100, "arcgis_sacramento": 200}},
            "rate_limiting": {"strategy": "exponential_backoff+jitter"},
            "error_recovery": {"retry_logic": {"max_retries": 3, "backoff_multiplier": 2}}
        }

    def create_quality_standards(self):
        self.catalog["quality_standards"] = {"completion_targets": {"field_completion_rate": "99.9%"}}

    def generate_acquisition_code(self, dataset_name: str, parameters: Dict) -> str:
        if dataset_name not in self.catalog["endpoint_registry"]:
            return f"# ERROR: Dataset '{dataset_name}' not found in catalog"
        endpoint_config = self.catalog["endpoint_registry"][dataset_name]
        template = f"# Auto-generated connector for {dataset_name}\n# base_url={endpoint_config.get('base_url')}\n"
        return template

    def save_catalog(self):
        out_dir = Path("./outputs")
        out_dir.mkdir(parents=True, exist_ok=True)
        catalog_path = out_dir / "ferengi_master_catalog.json"
        summary_path = out_dir / "ferengi_catalog_summary.json"
        with open(catalog_path, "w", encoding="utf-8") as f:
            json.dump(self.catalog, f, indent=2)
        summary = {
            "catalog_summary": {
                "total_api_categories": len(self.catalog["api_categories"]),
                "total_endpoints": len(self.catalog["endpoint_registry"]),
                "available_credentials": sum(1 for cred in self.env_credentials.values() if cred["status"] == "AVAILABLE"),
                "production_ready_apis": sum(1 for api in self.catalog["endpoint_registry"].values() if api.get("status") == "PRODUCTION_READY")
            },
            "credential_status": self.env_credentials
        }
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        return str(catalog_path), str(summary_path)

    def execute_catalog_creation(self):
        self.create_api_categories()
        self.create_endpoint_registry()
        self.create_authentication_methods()
        self.create_data_acquisition_protocols()
        self.create_quality_standards()
        # Load local source manifests (e.g., DCA physical datasets)
        try:
            self.load_source_manifests()
        except Exception:
            pass
        return self.save_catalog()


if __name__ == '__main__':
    c = FerengiMasterCatalog()
    catalog_path, summary_path = c.execute_catalog_creation()
    print('Wrote:', catalog_path, summary_path)
