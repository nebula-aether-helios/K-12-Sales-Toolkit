"""Simple HTTP call recorder used by enrichment modules to persist requests/responses for audit.
Writes a line to outputs/http_calls.log and saves response bodies to outputs/responses/*.json
"""
import json
from pathlib import Path
from datetime import datetime
import os


OUT_DIR = Path('outputs')
RESP_DIR = OUT_DIR / 'responses'
OUT_DIR.mkdir(parents=True, exist_ok=True)
RESP_DIR.mkdir(parents=True, exist_ok=True)


def record_http(name: str, url: str, params: dict, status: int, body: str):
    ts = datetime.utcnow().strftime('%Y%m%dT%H%M%S%f')
    entry = {
        'timestamp': datetime.utcnow().isoformat(),
        'name': name,
        'url': url,
        'params': params,
        'status': status
    }
    try:
        # write compact line to log
        with open(OUT_DIR / 'http_calls.log', 'a', encoding='utf-8') as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + '\n')
        # save body if present
        if body is not None:
            fn = RESP_DIR / f"{ts}_{name}.json"
            try:
                # try to pretty-print JSON
                parsed = json.loads(body)
                fn.write_text(json.dumps(parsed, indent=2, ensure_ascii=False), encoding='utf-8')
            except Exception:
                # raw text
                fn.write_text(body, encoding='utf-8', errors='replace')
    except Exception:
        # best-effort only
        pass
