#!/usr/bin/env python3
"""Create a sample SQLite DB for ferengi enrichment testing."""
import sqlite3
from pathlib import Path

OUT = Path("./outputs")
OUT.mkdir(exist_ok=True)
DB = OUT / "ferengi_enrichment.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

# Create table with columns used by the enrichment script
cur.execute('''
CREATE TABLE IF NOT EXISTS contractors (
    license_number TEXT PRIMARY KEY,
    business_name TEXT,
    address_city TEXT,
    enrich_status TEXT,
    record_updated_at TEXT,
    gp_place_id TEXT,
    gp_website TEXT,
    gp_rating REAL,
    gp_review_count INTEGER,
    gp_phone_verified INTEGER,
    gp_lat REAL,
    gp_lng REAL,
    gp_enriched_at TEXT,
    osha_inspection_count INTEGER,
    osha_violation_count INTEGER,
    osha_penalty_total INTEGER,
    osha_last_inspection_date TEXT,
    osha_open_cases INTEGER,
    osha_serious_violations INTEGER,
    osha_enriched_at TEXT,
    cl_ad_found INTEGER,
    cl_ad_url TEXT,
    cl_license_displayed INTEGER,
    cl_down_payment_violation INTEGER,
    cl_disaster_zone_ad INTEGER,
    cl_enriched_at TEXT,
    trigger_fear_osha_investigation INTEGER,
    trigger_fear_craigslist_violation INTEGER,
    trigger_envy_competitor_permits INTEGER,
    trigger_envy_govt_contracts INTEGER,
    trigger_envy_market_position INTEGER
)
''')

sample = [
    ("LIC-1001", "Alpha Contractors", "Sacramento", None),
    ("LIC-1002", "Beta Builders", "Sacramento", None),
    ("LIC-1003", "Gamma Renovations", "Sacramento", None),
    ("LIC-1004", "Delta Homes", "Sacramento", 'completed'),
    ("LIC-1005", "Epsilon Services", "Sacramento", None)
]

cur.executemany('INSERT OR IGNORE INTO contractors (license_number, business_name, address_city, enrich_status) VALUES (?,?,?,?)', sample)

conn.commit()
conn.close()

print(f"Created sample DB at {DB}")
