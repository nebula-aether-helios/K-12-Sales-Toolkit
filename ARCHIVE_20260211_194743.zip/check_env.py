import os
# Prefer DCA_API (new) but show legacy key name for compatibility
keys=['GOOGLE_PLACES_API_KEY','DCA_API','US_DEPT_OF_LABOR_API','ARCGIS_TOKEN','WAYBACK_BASE','RABBITMQ_URL']
for k in keys:
    val = os.getenv(k)
    # indicate if WAYBACK_BASE will fallback to default
    if k == 'WAYBACK_BASE' and not val:
        print(f"{k}: NOT SET (will default to https://web.archive.org)")
    else:
        print(f"{k}: {'SET' if val else 'MISSING'}")
