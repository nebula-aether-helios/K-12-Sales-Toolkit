# ============================================================================
# CELL1: Environment Variable Loader for V3 MVP
# ============================================================================
import os
from pathlib import Path
from dotenv import load_dotenv

# Try python-dotenv first, fallback to manual parsing
try:
    load_dotenv(".env.v3mvp")
    print("✅ Loaded environment variables via python-dotenv")
except:
    # Manual loader fallback
    env_path = Path(".env.v3mvp")
    if env_path.exists():
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key] = value.strip('"').strip("'")
        print("✅ Loaded environment variables via manual parser")
    else:
        print("⚠️ .env.v3mvp not found")

# ============================================================================
# ENRICHMENT API CONFIGURATION
# ============================================================================
ENRICHMENT_CONFIG = {
    #🔴 P0 - CRITICAL
    "mongodb_uri": os.getenv("MONGODB_URI"),
    "google_places_api_key": os.getenv("GOOGLE_PLACES_API_KEY"),
    "us_labor_api_key": os.getenv("US_DEPT_OF_LABOR_API"),
    
    # 🟠 P1 - IMPORTANT
    "arcgis_user": os.getenv("ERIS_ARCGIS_GEOHUB"),
    "la_city_api_key": os.getenv("DATA_LACITY_ORG_API_KEY_ID"),
    "rabbitmq_url": os.getenv("RABBITMQ_URL"),
    
    # 🟡 P2 - OPTIONAL
    "carto_client_id": os.getenv("CARTO_CLIENT_ID"),
    "titan_brain_ip": os.getenv("TITAN_BRAIN_IP"),
}

# Validation
print("\n📊 ENRICHMENT API STATUS:")
for key, value in ENRICHMENT_CONFIG.items():
    if value:
        masked = f"{value[:6]}...{value[-4:]}" if len(str(value)) > 10 else "***"
        print(f"  ✅ {key}: {masked}")
    else:
        print(f"  ❌ {key}: MISSING - will use FREE alternative")