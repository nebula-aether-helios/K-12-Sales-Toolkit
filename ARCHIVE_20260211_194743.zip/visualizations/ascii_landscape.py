import sqlite3
import math
import json
from datetime import datetime
from pathlib import Path

DEFAULT_GRID = (80, 24)


def load_charmap(path=None):
    if path and Path(path).exists():
        return json.loads(Path(path).read_text())
    default = Path(__file__).parent / "ach2_charmap.json"
    if default.exists():
        return json.loads(default.read_text())
    return [" ", ".", ":", "-", "=", "+", "*", "#", "%", "@"]


def _query_metric_values(db_path, metric_fields):
    # Try to read numeric metric fields from the prospects table; fall back to counts
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    rows = []
    try:
        f = metric_fields[0] if metric_fields else None
        if f:
            cur.execute(f"SELECT {', '.join(metric_fields)} FROM contractors")
            rows = cur.fetchall()
            # flatten to a single composite value per row by summing available numeric fields
            vals = []
            for r in rows:
                s = 0.0
                n = 0
                for v in r:
                    try:
                        s += float(v) if v is not None else 0.0
                        n += 1
                    except Exception:
                        continue
                vals.append(s / n if n else 0.0)
            return vals
    except Exception:
        pass
    # fallback: use 0/1 enriched flag
    try:
        cur.execute("SELECT enriched_flag FROM contractors")
        vals = [float(r[0] or 0.0) for r in cur.fetchall()]
        return vals
    except Exception:
        # last resort: return empty
        return []
    finally:
        conn.close()


def _bin_values_to_grid(values, grid_x, grid_y):
    # create grid and fill by averaging values that fall into each cell
    cells = [[[] for _ in range(grid_x)] for _ in range(grid_y)]
    n = len(values)
    if n == 0:
        return [[0.0 for _ in range(grid_x)] for _ in range(grid_y)]
    for i, v in enumerate(values):
        # map index to 2D position by simple scatter
        x = int((i % grid_x))
        y = int((i * grid_x // n) % grid_y)
        cells[y][x].append(v)
    grid = [[(sum(c) / len(c) if c else 0.0) for c in row] for row in cells]
    return grid


def _normalize_grid(grid):
    flat = [v for row in grid for v in row]
    if not flat:
        return grid
    mn = min(flat)
    mx = max(flat)
    if mx - mn <= 0:
        return [[0.0 for _ in row] for row in grid]
    return [[(v - mn) / (mx - mn) for v in row] for row in grid]


def render_from_db(db_path, metric_fields=None, grid_size=None, charmap_path=None, output_path=None, print_to_terminal=True):
    grid_x, grid_y = grid_size or DEFAULT_GRID
    vals = _query_metric_values(db_path, metric_fields or [])
    grid = _bin_values_to_grid(vals, grid_x, grid_y)
    grid = _normalize_grid(grid)
    charmap = load_charmap(charmap_path)
    levels = len(charmap)

    lines = []
    # simple perspective: render from top row to bottom with optional skew
    for y in range(len(grid)):
        row = grid[y]
        line = []
        for x, v in enumerate(row):
            idx = min(levels - 1, int(v * (levels - 1)))
            line.append(charmap[idx])
        lines.append("".join(line))

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path(output_path) if output_path else Path("outputs")
    out_dir.mkdir(parents=True, exist_ok=True)
    fname = out_dir / f"enrichment_landscape_{ts}.txt"
    fname.write_text("\n".join(lines), encoding="utf8")

    hotspots = []
    # compute hotspots: top 5 cells by normalized value
    flat = []
    for y, row in enumerate(grid):
        for x, v in enumerate(row):
            flat.append((v, x, y))
    flat.sort(reverse=True)
    for v, x, y in flat[:10]:
        hotspots.append({"x": x, "y": y, "value": v})
    hotname = out_dir / f"enrichment_landscape_hotspots_{ts}.json"
    hotname.write_text(json.dumps({"hotspots": hotspots}, indent=2), encoding="utf8")

    summary = {
        "timestamp": ts,
        "grid": {"x": grid_x, "y": grid_y},
        "cells": sum(1 for _ in flat),
        "hotspots_file": str(hotname.name),
        "landscape_file": str(fname.name)
    }
    summary_name = out_dir / f"enrichment_landscape_summary_{ts}.json"
    summary_name.write_text(json.dumps(summary, indent=2), encoding="utf8")

    if print_to_terminal:
        print("\n".join(lines))
        print(f"Landscape saved: {fname}")
        print(f"Hotspots saved: {hotname}")
    return str(fname)
