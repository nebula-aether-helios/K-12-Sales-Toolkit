"""Publish pending prospects to RabbitMQ queue for distributed workers.
If RABBITMQ_URL is unset, this script will exit with a message.
"""
import os
import sqlite3
import json
import pika

RABBITMQ_URL = os.getenv("RABBITMQ_URL")
QUEUE_NAME = os.getenv("RABBITMQ_QUEUE", "ferengi_enrich_jobs")
DB_PATH = os.getenv("FERENGI_DB", "./outputs/ferengi_enrichment.db")


def publish_all():
    if not RABBITMQ_URL:
        print("RABBITMQ_URL not set in environment; exiting producer.")
        return

    params = pika.URLParameters(RABBITMQ_URL)
    conn = pika.BlockingConnection(params)
    ch = conn.channel()
    ch.queue_declare(queue=QUEUE_NAME, durable=True)

    conn_db = sqlite3.connect(DB_PATH)
    cur = conn_db.cursor()
    cur.execute("SELECT license_number FROM contractors WHERE enrich_status != 'completed' OR enrich_status IS NULL")
    rows = cur.fetchall()
    print(f"Publishing {len(rows)} jobs to queue {QUEUE_NAME}")

    for (license_number,) in rows:
        payload = json.dumps({"license_number": license_number})
        ch.basic_publish(exchange='', routing_key=QUEUE_NAME, body=payload, properties=pika.BasicProperties(delivery_mode=2))

    conn.close()
    conn_db.close()
    print("Published all pending jobs.")


if __name__ == '__main__':
    publish_all()
