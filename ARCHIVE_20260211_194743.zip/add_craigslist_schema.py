"""Add missing Craigslist schema columns (37 fields) to the contractors table if they don't exist."""
from pathlib import Path
import sqlite3

DB = Path("./outputs/ferengi_enrichment.db")

CR_FIELDS = [
    # example set of 37 craigslist fields prefixed with cl_
    "cl_ad_found",
    "cl_ad_url",
    "cl_license_displayed",
    "cl_down_payment_violation",
    "cl_disaster_zone_ad",
    "cl_enriched_at",
    "cl_owner_name",
    "cl_owner_phone",
    "cl_owner_email",
    "cl_safety_claim",
    "cl_price_claim",
    "cl_multiple_ads",
    "cl_region",
    "cl_category",
    "cl_posted_date",
    "cl_updated_date",
    "cl_images_count",
    "cl_contact_method",
    "cl_payment_terms",
    "cl_listing_id",
    "cl_phone_in_title",
    "cl_text_snippet",
    "cl_raw_json",
    "cl_wayback_count",
    "cl_wayback_matches",
    "cl_historical_ads",
    "cl_scam_flags",
    "cl_competitor_licenses",
    "cl_address_in_ad",
    "cl_city_in_ad",
    "cl_state_in_ad",
    "cl_zip_in_ad",
    "cl_price_low",
    "cl_price_high",
    "cl_fake_images_detected",
]


def ensure_schema(db_path: str = None):
    p = DB if db_path is None else Path(db_path)
    if not p.exists():
        print("Database not found:", p)
        return

    conn = sqlite3.connect(str(p))
    cur = conn.cursor()

    cur.execute("PRAGMA table_info(contractors)")
    existing = set(r[1] for r in cur.fetchall())

    for col in CR_FIELDS:
        if col not in existing:
            try:
                print("Adding column:", col)
                cur.execute(f"ALTER TABLE contractors ADD COLUMN '{col}' TEXT")
            except Exception as e:
                print("Failed to add", col, e)

    conn.commit()
    conn.close()


if __name__ == "__main__":
    ensure_schema()
    print("Craigslist schema ensured.")
