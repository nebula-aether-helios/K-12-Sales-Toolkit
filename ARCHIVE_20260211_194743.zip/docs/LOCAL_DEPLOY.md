Local deployment (Docker + Compose)
=================================

This repository can run locally via Docker Compose. The stack includes:
- app (your code)
- redis (cache)
- rabbitmq (message broker)

Quick start
-----------
Requires Docker and Docker Compose (v2).

Build and start the stack:

```bash
./scripts/run_local.sh
```

Open RabbitMQ management at http://localhost:15672 (guest/guest)

Notes
-----
- The app mounts the repository and `./outputs` as a volume so local files persist.
- The container sets `PYTHONPATH=/app` so internal imports resolve.

CI
--
The GitHub Actions workflow `ci.yml` runs tests and a migration dry-run on PRs.
