# Implementation Roadmap (high level)

This document outlines milestone phases and rough timelines for completing the full
enrichment production system locally and preparing for deployment.

Phases

1. Stabilize local runtime (0-2 days)
   - In-memory queue + multi-worker orchestrator (done)
   - Canonical ORM and migration (done)
   - Add OSHA & SBA adapters (done)

2. Adapter expansion & tests (3-7 days)
   - Implement remaining authoritative adapters (SBA, state registries, licensing sources)
   - Add unit/integration tests and mocked network layers

3. Worker robustness & observability (2-4 days)
   - Add metrics (Prometheus/statsd), structured logging
   - Retry/backoff improvements and DLQ

4. Secrets & rate-limiting (2-3 days)
   - Integrate secrets manager (Vault/KeyVault) for API keys
   - Implement rate-limiters per adapter

5. Scale & deployment (4-7 days)
   - Switch to persistent queue (RabbitMQ) and supervised workers
   - Create container images and compose/k8s manifests

6. Production hardening (ongoing)
   - Security review, compliance checks, monitoring dashboards, runbooks

Notes
- Timelines are estimates for a small team and assume adapters that are straightforward to implement.
- Prioritization: implement authoritative data sources (OSHA/SBA/state licensing) first.
