## Runbook — Local production run (no Docker)

This runbook documents how to run the full enrichment pipeline locally using the in-memory queue and multiple workers.

Prerequisites
- Python 3.11 (matching project)
- Install requirements: `pip install -r requirements.txt`
- Ensure `PYTHONPATH` includes the repo root (or run from repo root and use `python -m` as needed)

Environment
- Copy `.env.example` to `.env` and fill paths/keys. Do NOT commit `.env`.
- Ensure `LOCAL_QUEUE=1` to use the in-memory queue.

Commands
- Start a local run with 4 workers:
```powershell
$env:LOCAL_QUEUE = '1'
$env:PYTHONPATH = 'C:\Users\aether\Documents\GitHub\azuredev-2005'
python scripts/run_local_production.py --db outputs/enrichment.db --workers 4
```

Stopping
- The orchestrator sends stop sentinels when work is drained. To force-stop, kill the processes.

Monitoring
- Logs are printed to stdout. For more observability, forward stdout to a file or wire to a log aggregator.

Next steps
- For production, replace in-memory queue with RabbitMQ (unset `LOCAL_QUEUE` and ensure `RABBITMQ_URL` is set).
- Add rate-limiting and secret management before running against production endpoints.
