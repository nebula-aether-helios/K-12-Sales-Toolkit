#!/usr/bin/env python3
"""Analyze enrichment results in ./outputs/ferengi_enrichment.db and write a report."""
import sqlite3
import json
from pathlib import Path
import statistics
import csv

DB_PATH = Path("./outputs/ferengi_enrichment.db")
OUT_DIR = Path("./outputs")
OUT_DIR.mkdir(parents=True, exist_ok=True)

def fetch_one(cursor, query, params=()):
    cursor.execute(query, params)
    return cursor.fetchone()[0]

def main():
    if not DB_PATH.exists():
        print("DB not found:", DB_PATH)
        return 1

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    total = fetch_one(cur, "SELECT COUNT(*) FROM contractors")
    completed = fetch_one(cur, "SELECT COUNT(*) FROM contractors WHERE enrich_status = 'completed'")
    errors = fetch_one(cur, "SELECT COUNT(*) FROM contractors WHERE enrich_status = 'error'")

    # gp_rating stats
    cur.execute("SELECT gp_rating FROM contractors WHERE gp_rating IS NOT NULL")
    raw_ratings = [r[0] for r in cur.fetchall()]
    ratings = []
    for v in raw_ratings:
        try:
            # attempt to coerce string numeric values to float
            if v is None or v == "":
                continue
            rv = float(v)
            ratings.append(rv)
        except Exception:
            # skip non-numeric values
            continue
    rating_stats = {}
    if ratings:
        rating_stats = {
            "count": len(ratings),
            "mean": statistics.mean(ratings),
            "median": statistics.median(ratings),
            "min": min(ratings),
            "max": max(ratings)
        }

    osha_violations = fetch_one(cur, "SELECT COUNT(*) FROM contractors WHERE CAST(osha_violation_count AS INTEGER) > 0")
    craigslist_ads = fetch_one(cur, "SELECT COUNT(*) FROM contractors WHERE CAST(cl_ad_found AS INTEGER) = 1")

    # triggers - find columns starting with 'trigger_'
    cur.execute("PRAGMA table_info(contractors)")
    cols = [r[1] for r in cur.fetchall()]
    trigger_cols = [c for c in cols if c.startswith("trigger_")]
    trigger_counts = {}
    for t in trigger_cols:
        trigger_counts[t] = fetch_one(cur, f"SELECT COUNT(*) FROM contractors WHERE {t} = 1")

    # sample completed rows
    sample_cols = ["license_number","business_name","enrich_status","gp_rating","osha_violation_count","cl_ad_found","trigger_fear_osha_investigation","record_updated_at"]
    cur.execute(f"SELECT {','.join(sample_cols)} FROM contractors WHERE enrich_status = 'completed' LIMIT 20")
    samples = [dict(zip(sample_cols, row)) for row in cur.fetchall()]

    report = {
        "total_records": total,
        "completed": completed,
        "errors": errors,
        "completion_rate": f"{(completed/total*100) if total else 0:.2f}%",
        "gp_rating_stats": rating_stats,
        "osha_violations_count": osha_violations,
        "craigslist_ads_count": craigslist_ads,
        "trigger_counts": trigger_counts,
        "sample_rows_count": len(samples)
    }

    report_path = OUT_DIR / "enrichment_analysis.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    sample_csv = OUT_DIR / "enrichment_sample_completed.csv"
    with open(sample_csv, "w", newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=sample_cols)
        writer.writeheader()
        for r in samples:
            writer.writerow(r)

    conn.close()

    print("Analysis saved:", report_path)
    print("Sample CSV:", sample_csv)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
