#!/usr/bin/env python3
"""Import the Sacramento contractors CSV into ./outputs/ferengi_enrichment.db

This will create/replace a table named `contractors`. Uses chunked import to handle large files.
"""
import sqlite3
from pathlib import Path
import pandas as pd
import sys

CSV_PATH = sys.argv[1] if len(sys.argv) > 1 else "./sacramento_contractors_cslb_sac.csv"
OUT_DB = Path("./outputs/ferengi_enrichment.db")
OUT_DB.parent.mkdir(parents=True, exist_ok=True)

print(f"Importing {CSV_PATH} -> {OUT_DB}")

chunksize = 20000
first = True
rows = 0

# open a sqlite3 connection and pass it to pandas.to_sql
conn = sqlite3.connect(OUT_DB)
for chunk in pd.read_csv(CSV_PATH, chunksize=chunksize, dtype=str, keep_default_na=False):
    # normalize column names
    chunk.columns = [c.strip() for c in chunk.columns]
    if first:
        chunk.to_sql("contractors", conn, if_exists="replace", index=False)
        first = False
    else:
        chunk.to_sql("contractors", conn, if_exists="append", index=False)
    rows += len(chunk)
    print(f"Imported {rows} rows...")

# create an index on license_number to speed lookups
cur = conn.cursor()
try:
    cur.execute("CREATE INDEX IF NOT EXISTS idx_license_number ON contractors(license_number)")
    conn.commit()
except Exception as e:
    print("Failed to create index:", e)
finally:
    conn.close()

print(f"Done. Total rows imported: {rows}")
