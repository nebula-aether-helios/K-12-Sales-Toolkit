# Proposed Toolset, Keys, Credentials, and Secrets for Enrichment (Draft)

## Objectives
- Align with v1 architecture (control center + adversarial gate), v2 enrichment logic (truthful, channel-rich monetization), and v3 schema (6-source enrichment + primary/secondary reports).
- Use available in-repo tools first; avoid new dependencies unless justified.
- Prepare for real-data testing on 10 Sacramento prospects, then wire into v3 notebook and Mongo migration.

## Primary Enrichment Sources (v3 schema) and Best-Fit Tools
- Google Places API (`gp_*`): Use Google Places/Business API via official REST; needs `GOOGLE_PLACES_API_KEY` and query by business name + city/zip. Output rating, reviews, phone_verified, website, hours, lat/lng.
- OSHA Data Door (`osha_*`): Use OSHA API (public, rate-limited) for inspection/violation counts by company/state; no key or optional app token. Map to inspection_count, violation_count, last_inspection_date, penalty_total.
- ArcGIS Permits (`permit_*`): Use Sacramento GeoHub/ArcGIS REST; no key for open layers. Fields: active_count, total_value, last_issued_date, types. Crosswalk permits to license/business name.
- Craigslist/Recondon (`cl_*`): Use RECONDON TITAN V14 BERT async crawler (current repo). Outputs ad_found, ad_url, description, license_displayed (needs regex), down_payment_violation flag, sentiment, bert_entities.
- OSINT/Social (`osint_*`): Use OSINT utilities and dorkers:
  - `osint_utils.py` (MX validation, DNS check, phone audit) for contact confidence.
  - `ozzyOsint.py` for DNS footprint, derive domain from business name.
  - `titan_v13_dorker.py` (Playwright) for OSHA/legal/reputation dorks.
  - `test_dork_gen.py` templates for social/profile dorks.
- Court Records (`court_*`): Use dorking (CourtListener) + Wayback (`ReconDon_Wayback_Discovery.py`) to surface historical/legal hits; map to case_count/lien_count/judgment_total flags (needs parsing heuristic).

## Support Tools from Inventory
- Phone OSINT: PhoneInfoga binary (`phoneinfoga.exe`) or `audit_phone_deep()` to score carrier/VoIP indicators.
- DNS Recon: `dnsrecon`, `amass`, `assetfinder`, `fierce` for domain validation when a domain is derived.
- Dorking/Recon: `googledork.py`, `buster` modules for email/profile harvest; `finalrecon`, `cmsmap` for site fingerprinting.
- Queue/Pipeline: `recondon_consumer.py` for RabbitMQ ingestion (if queueing Craigslist runs); `pipeline_production.json` as manifest reference.

## Credential/Key Handling (do not hardcode in notebook)
- Use environment variables or `.env` loaded via `os.environ`:
  - `GOOGLE_PLACES_API_KEY`
  - `OSHA_APP_TOKEN` (optional if available)
  - `ARC_GIS_TOKEN` (if required for private layers; public layers need none)
  - `PLAYWRIGHT_BROWSER_PATH` (if using custom chromium) and `PLAYWRIGHT_HEADLESS=true`
- Secrets present in v1 file must be relocated to env vars before wiring into v3 to avoid notebook leakage.

## Minimal Test Plan (10 prospects, real data)
- Input: sample of 10 licenses from `sacramento_contractors_cslb_sac.csv` (or embedded v3 data).
- Steps per prospect:
  1) Derive search bundle (business name, city, zip, license_number).
  2) Google Places lookup → write `gp_*`, set `enrich_google_places_done`.
  3) OSHA lookup by name/state → write `osha_*`, set trigger if violations >0.
  4) ArcGIS permits query by name/address/zip → `permit_*`, set envy trigger.
  5) RECONDON crawl for CRAIGSLIST region `sacramento` (categories `sss`,`cto`) → `cl_*`, set fear trigger if down-payment terms violate.
  6) OSINT/Dorking → email/phone/domain confidence, social/profile hits → `osint_*`, update risk/trigger fields.
  7) Court/wayback dorks → `court_*` heuristics.
- Acceptance: at least 7/10 records gain new fields in ≥3 sources; boolean flags normalized; enrichment_status moves to `partial` or `complete` accordingly.

## Notebook Integration Plan (high level)
- Add an enrichment orchestrator cell that:
  - Loads 10-prospect sample dataframe.
  - Runs source-specific functions (async for RECONDON + HTTP APIs for others).
  - Normalizes outputs into v3 fields and reuses existing trigger→report mapping cell.
  - Writes interim CSV/JSON to `outputs/` and updates in-memory data for summary.
- Keep credentials outside the notebook; read via env.
- Preserve v3 primary/secondary report logic; extend catalog if new signals appear (e.g., sentiment from Craigslist, DNS reputation from OSINT).

## Open Questions/Risks
- Network access and rate limits for Google Places/OSHA/ArcGIS in this environment.
- Playwright availability (Chromium download) for `titan_v13_dorker.py`.
- PhoneInfoga binary not present here; may need pip version or skip.
- Court hit parsing is heuristic; may need manual validation before setting `court_*` fields.

## Next Actions (for execution phase)
- Confirm usable API keys and network allowance for external calls.
- Implement source-specific adapters in a new v3 enrichment cell (with retry/backoff and logging).
- Run the 10-prospect test; record real outputs in `outputs/enrichment_run_10.json` and `outputs/enrichment_run_10.csv`.
- Update `enrich_status` and triggers, then proceed to Mongo migration cell.
