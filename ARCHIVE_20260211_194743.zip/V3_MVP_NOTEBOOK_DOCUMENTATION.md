# V3 MVP Notebook - Real Enrichment Pipeline Documentation

## Overview

The `v3mvp.ipynb` notebook is a production-ready data processing and enrichment pipeline for the Sacramento contractor database (9,739 records). It uses **real data** and **free proprietary tools** - no mocked responses or paid API dependencies for core OSINT functions.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                    V3 MVP NOTEBOOK PIPELINE                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐            │
│  │ CELL 1       │   │ CELL 2       │   │ CELLS 3-4    │            │
│  │ ENV LOADER   │──▶│ SCHEMA DOCS  │──▶│ DB CLASS +   │            │
│  │ (.env.v3mvp) │   │ (Markdown)   │   │ EMBEDDED DATA│            │
│  └──────────────┘   └──────────────┘   └──────────────┘            │
│         │                                      │                    │
│         ▼                                      ▼                    │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐            │
│  │ os.getenv()  │   │ CELL 5       │   │ CELL 6-7     │            │
│  │ API Keys     │◀──│ AI ENGINE    │──▶│ DATA LOAD +  │            │
│  │ MongoDB URI  │   │ Mission Brief│   │ BOOL NORMALIZE│           │
│  └──────────────┘   └──────────────┘   └──────────────┘            │
│                                                │                    │
│                                                ▼                    │
│  ┌──────────────────────────────────────────────────────┐          │
│  │ CELL 8: TRIGGER → REPORT MAPPING                     │          │
│  │ • OSHA violations → trigger_fear_osha_investigation  │          │
│  │ • CL violations → trigger_fear_craigslist_violation  │          │
│  │ • Permits → trigger_envy_competitor_permits          │          │
│  │ • Segments → auto-triggers per law impact            │          │
│  └──────────────────────────────────────────────────────┘          │
│                          │                                          │
│                          ▼                                          │
│  ┌──────────────────────────────────────────────────────┐          │
│  │ CELL 11: DEEP OSINT ENRICHMENT                       │          │
│  │ • DNS/MX validation (dnspython)                      │          │
│  │ • Phone parsing (phonenumbers lib)                   │          │
│  │ • RECONDON Craigslist crawler (async aiohttp)        │          │
│  │ • License number matching in ads                     │          │
│  │ • Down-payment violation detection                   │          │
│  └──────────────────────────────────────────────────────┘          │
│                          │                                          │
│                          ▼                                          │
│  ┌──────────────┐   ┌──────────────┐                               │
│  │ CELL 9       │   │ CELL 10      │                               │
│  │ REPORT       │   │ CSV EXPORT   │                               │
│  │ CATALOG      │   │ (outputs/)   │                               │
│  └──────────────┘   └──────────────┘                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Cell-by-Cell Breakdown

### Cell 1: Environment Variable Loader
- Loads `.env.v3mvp` via python-dotenv (fallback: manual parser)
- Exposes `ENRICHMENT_CONFIG` dict with masked validation output
- Keys: `MONGODB_URI`, `GOOGLE_PLACES_API_KEY`, `US_DEPT_OF_LABOR_API`, `RABBITMQ_URL`, etc.

### Cell 2: Schema Documentation (Markdown)
- 129-field MongoDB schema reference
- Segment breakdown with counts
- Recommended indexes
- Enrichment pipeline workflow

### Cell 3: SacramentoContractorDB Class
- In-memory database with 9,739 embedded records
- Methods: `get()`, `query()`, `update()`, `bulk_update()`, `segment_counts()`, `enrichment_status()`
- MongoDB-ready export via `to_mongodb_docs()`

### Cell 4: AIDataEngine Class
- db in the notebook
- Pain/Envy score calculations
- Conversion probability (sigmoid)
- Enrichment priority classification

### Cell 5: Secondary Reports Markdown
- 100 report products ($9-$159)
- Bundle definitions (Starter $39.99, Growth $59.99, Elite $97)
- VISME JSON structure for PDF generation

### Cell 6: Data Load & Boolean Normalization
- Loads `sacramento_contractors_cslb_sac.csv`
- Normalizes 40+ boolean flag fields
- Validates enrichment status

### Cell 7: Trigger → Report Mapping
- Applies deterministic trigger logic:
  - `osha_violation_count > 0` → `trigger_fear_osha_investigation`
  - `cl_down_payment_violation` → `trigger_fear_craigslist_violation`
  - `permit_active_count > 0` → `trigger_envy_competitor_permits`
  - Segment-based auto-triggers (SB517, LA expansion, etc.)
- Updates `enrich_status` (pending/partial/complete)

### Cell 8: Secondary Report Catalog
- JSON catalog with 6 sample reports
- Bundle definitions
- Saves to `outputs/report_catalog.json`, `outputs/report_bundles.json`

### Cell 9: CSV Export
- Saves enriched data to `outputs/sacramento_contractors_enriched.csv`

### Cell 10: Empty (placeholder)

### Cell 11: Deep OSINT Enrichment ⭐
**Real enrichment using free tools:**

| Function | Tool | Output |
|----------|------|--------|
| Domain derivation | Regex | `derived_domain` |
| DNS A record check | dnspython | `domain_has_a` |
| MX record validation | dnspython | `domain_has_mx`, `mx_records` |
| DNS score | Algorithm | `dns_score` (0-100) |
| Phone parsing | phonenumbers lib | `phone_valid`, `phone_carrier`, `phone_type`, `phone_region` |
| Craigslist crawl | RECONDON async | `cl_ad_found`, `cl_ad_url` |
| License matching | Regex | `cl_license_displayed` |
| Violation detection | Regex | `cl_down_payment_violation` |
| Trigger activation | Logic | `trigger_fear_craigslist_violation` |

---

## Enrichment Sources (6 Total)

| Source | Prefix | Status | Tool |
|--------|--------|--------|------|
| Google Places | `gp_*` | Optional (API key) | Google Places API |
| OSHA | `osha_*` | Free | US DOL API / DDG dorking |
| ArcGIS Permits | `permit_*` | Free | Sacramento GeoHub REST |
| Craigslist | `cl_*` | **Working** | RECONDON async crawler |
| OSINT/Social | `osint_*` | **Working** | DNS/MX/Phone libs |
| Court Records | `court_*` | Free | DDG dorking |

---

## Primal Trigger Framework

### Fear Triggers (8)
| # | Trigger | Set By |
|---|---------|--------|
| 1 | `trigger_fear_disaster_zone` | Manual/Geo |
| 2 | `trigger_fear_ab1327_deadline` | `seg_home_improvement` |
| 3 | `trigger_fear_sb291_penalty` | `seg_wc_exposure` |
| 4 | `trigger_fear_sb779_fine` | Manual/Date |
| 5 | `trigger_fear_nascla_sweep` | Manual/News |
| 6 | `trigger_fear_ab1002_wage` | Manual |
| 7 | `trigger_fear_osha_investigation` | OSHA enrichment |
| 8 | `trigger_fear_craigslist_violation` | **RECONDON crawler** |

### Envy Triggers (5)
| # | Trigger | Set By |
|---|---------|--------|
| 1 | `trigger_envy_competitor_permits` | Permit enrichment |
| 2 | `trigger_envy_govt_contracts` | Contract enrichment |
| 3 | `trigger_envy_market_position` | Ranking algorithm |
| 4 | `trigger_envy_sb517_compliance` | `seg_general_contractor` |
| 5 | `trigger_envy_la_expansion` | `seg_has_la_presence` |

---

## Test Results (10-Prospect Sample)

From `outputs/deep_osint_20260204_185248.csv`:

| License | DNS Score | Phone Valid | CL Found | Triggers |
|---------|-----------|-------------|----------|----------|
| 1000019 | 85 | ✅ | ❌ | - |
| 1000027 | 40 | ✅ | ❌ | - |
| 1000103 | 40 | ✅ | ❌ | - |
| 1000130 | 0 | ✅ | ❌ | - |
| 1000137 | 0 | ✅ | ❌ | - |
| 1000268 | 0 | ✅ | ❌ | - |
| 1000283 | 85 | ✅ | ❌ | - |
| 1000307 | 40 | ✅ | ❌ | - |
| 1000370 | 85 | ✅ | ❌ | - |
| 1000448 | 0 | ✅ | ❌ | - |

**Key Findings:**
- ✅ 10/10 phones validated (US, California, FIXED_OR_MOBILE)
- ✅ 4/10 domains have MX records (email capable)
- ✅ 6/10 domains have A records (website exists)
- ✅ RECONDON crawled 100 Craigslist listings, found 30 license mentions
- ⚪ No direct matches for this sample (expected for random selection)

---

## File Structure

```
/workspaces/codespaces-jupyter/
├── v3mvp.ipynb                    # Main notebook (41MB with embedded data)
├── .env.v3mvp                     # Environment variables (gitignored)
├── sacramento_contractors_cslb_sac.csv  # Source data (7.6MB)
├── deep_osint_enrichment.py       # Standalone enrichment script
├── enrichment_pipeline_runner.py  # API-based enrichment
├── notebook_env_loader.py         # Env loader module
└── outputs/
    ├── deep_osint_*.json          # OSINT results (JSON)
    ├── deep_osint_*.csv           # OSINT results (CSV)
    ├── enrichment_run_10.json     # API enrichment results
    ├── report_catalog.json        # Report products
    └── report_bundles.json        # Bundle definitions
```

---

## Usage

1. **Load environment:**
   - Ensure `.env.v3mvp` exists with required keys
   - Run Cell 1 to validate

2. **Run enrichment:**
   - Execute cells sequentially
   - Cell 11 runs deep OSINT on 10-prospect sample
   - Results update in-memory DataFrame

3. **Export:**
   - Cell 9 saves enriched CSV
   - Cell 10 placeholder for MongoDB migration

4. **Standalone testing:**
   ```bash
   python deep_osint_enrichment.py
   ```

---

## Security Notes

- `.env.v3mvp` is in `.gitignore` - never committed
- All secrets accessed via `os.getenv()` - no hardcoding
- Notebook outputs sanitized before commit

---

## Next Steps

- [ ] Wire MongoDB migration cell (when URI confirmed)
- [ ] Expand Craigslist regions (LA, SF Bay)
- [ ] Add Google Places enrichment (API key required)
- [ ] Implement court record dorking
- [ ] Create VISME PDF templates
