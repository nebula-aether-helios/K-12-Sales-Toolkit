# v3_realignment_config.py
# V3 MVP Realignment - Product Hierarchy & Schema Validation
# Restores v2 foundation: PRIMARY reports promoted, SECONDARY for self-discovery
# Created: 2026-02-04
import hashlib
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════════════
# USE CASE DOC LOCK - Immutable Reference
# ═══════════════════════════════════════════════════════════════════════════════════════
USE_CASE_DOC_VERSION = "2026-02-04"
USE_CASE_DOC_LOCKED = True  # Schema changes require version bump

# ═══════════════════════════════════════════════════════════════════════════════════════
# PRIMARY REPORT CATALOG (10 Core Products - v2 Foundation)
# These are the ONLY reports promoted in chatbot flow steps 2-4
# ═══════════════════════════════════════════════════════════════════════════════════════
PRIMARY_REPORT_CATALOG = {
    "version": "2.0",
    "total_products": 10,
    "chatbot_promoted": True,
    "tier_1_fear": [
        {
            "id": "LSA",
            "name": "License Suspension Alert",
            "price": 19.99,
            "trigger_field": "seg_has_suspension",
            "report_flag": "report_license_suspension_alert",
            "fear_trigger": "trigger_fear_nascla_sweep",
            "description": "Immediate alert on suspension status with reinstatement roadmap",
            "visme_template": "LSA_template_v1"
        },
        {
            "id": "CCD",
            "name": "2026 Compliance Deadline Report",
            "price": 19.99,
            "trigger_field": "law_any_2026_impact",
            "report_flag": "report_2026_compliance_deadline",
            "fear_trigger": "trigger_fear_ab1327_deadline",
            "description": "Complete 2026 law impact analysis (AB 1327, SB 517, SB 291)",
            "visme_template": "CCD_template_v1"
        },
        {
            "id": "WCE",
            "name": "Workers Comp Exposure Audit",
            "price": 19.99,
            "trigger_field": "seg_wc_exposure",
            "report_flag": "report_wc_exposure_audit",
            "fear_trigger": "trigger_fear_sb291_penalty",
            "description": "SB 291 penalty risk assessment ($15,000+ exposure)",
            "visme_template": "WCE_template_v1"
        },
        {
            "id": "OIR",
            "name": "OSHA Investigation Risk Report",
            "price": 19.99,
            "trigger_field": "trigger_fear_osha_investigation",
            "report_flag": "report_osha_risk",
            "fear_trigger": "trigger_fear_osha_investigation",
            "description": "OSHA violation history and penalty exposure analysis",
            "visme_template": "OIR_template_v1"
        },
        {
            "id": "CCA",
            "name": "Craigslist Competitor Analysis",
            "price": 19.99,
            "trigger_field": "trigger_fear_craigslist_violation",
            "report_flag": "report_craigslist_competitor",
            "fear_trigger": "trigger_fear_craigslist_violation",
            "description": "Unlicensed competitor detection and violation evidence",
            "visme_template": "CCA_template_v1"
        },
        {
            "id": "CPT",
            "name": "Competitor Permit Tracker",
            "price": 19.99,
            "trigger_field": "trigger_envy_competitor_permits",
            "report_flag": "report_competitor_permit_tracker",
            "envy_trigger": "trigger_envy_competitor_permits",
            "description": "Real-time competitor permit activity in your market",
            "visme_template": "CPT_template_v1"
        }
    ],
    
    "tier_2_envy": [
        {
            "id": "GCI",
            "name": "Government Contract Intel",
            "price": 29.99,
            "trigger_field": "trigger_envy_govt_contracts",
            "report_flag": "report_govt_contract_intel",
            "envy_trigger": "trigger_envy_govt_contracts",
            "description": "Government contract opportunities and competitor awards",
            "visme_template": "GCI_template_v1"
        },
        {
            "id": "SVP",
            "name": "Subcontractor Verification Pack",
            "price": 29.99,
            "trigger_field": "seg_general_contractor",
            "report_flag": "report_subcontractor_verification",
            "envy_trigger": "trigger_envy_sb517_compliance",
            "description": "SB 517 compliance verification for subcontractor management",
            "visme_template": "SVP_template_v1"
        }
    ],
    
    "tier_3_premium": [
        {
            "id": "MPA",
            "name": "Market Position Analysis",
            "price": 49.99,
            "trigger_field": "trigger_envy_market_position",
            "report_flag": "report_market_position",
            "envy_trigger": "trigger_envy_market_position",
            "description": "Comprehensive market ranking and competitive intelligence",
            "visme_template": "MPA_template_v1"
        },
        {
            "id": "LME",
            "name": "LA Market Expansion Report",
            "price": 49.99,
            "trigger_field": "seg_has_la_presence",
            "report_flag": "report_la_expansion",
            "envy_trigger": "trigger_envy_la_expansion",
            "description": "Cross-market intelligence for Sacramento-LA expansion",
            "visme_template": "LME_template_v1"
        }
    ]
}

# ═══════════════════════════════════════════════════════════════════════════════════════
# SECONDARY REPORT CATALOG (100 Additional Products - Self-Discovery Only)
# NOT promoted in chatbot flow - available via "Browse All Reports" link
# ═══════════════════════════════════════════════════════════════════════════════════════
SECONDARY_REPORT_CATALOG = {
    "version": "1.0",
    "total_products": 100,
    "chatbot_promoted": False,  # KEY DIFFERENCE from v3 deviation
    "access_method": "browse_all_reports_link",
    
    "categories": [
        {"name": "Compliance Deep Dives", "count": 15, "price_range": "$9.99-$29.99"},
        {"name": "Insurance & Bonding", "count": 12, "price_range": "$14.99-$39.99"},
        {"name": "Market Intelligence", "count": 20, "price_range": "$19.99-$79.99"},
        {"name": "Legal & Enforcement", "count": 18, "price_range": "$19.99-$99.99"},
        {"name": "Business Development", "count": 25, "price_range": "$29.99-$159.99"},
        {"name": "Training & Certification", "count": 10, "price_range": "$9.99-$49.99"}
    ]
}

# ═══════════════════════════════════════════════════════════════════════════════════════
# BUNDLE DEFINITIONS (v2 Foundation)
# ═══════════════════════════════════════════════════════════════════════════════════════
REPORT_BUNDLES = {
    "starter": {"name": "Starter Bundle", "price": 39.99, "savings": "20%", "includes": ["LSA", "CCD"], "target_segment": "seg_license_expiring_90d"},
    "growth": {"name": "Growth Bundle", "price": 59.99, "savings": "25%", "includes": ["CCD", "WCE", "CPT"], "target_segment": "law_any_2026_impact"},
    "elite": {"name": "Elite Bundle", "price": 97.00, "savings": "35%", "includes": ["CCD", "WCE", "OIR", "CCA", "CPT"], "target_segment": "seg_general_contractor"}
}

# ═══════════════════════════════════════════════════════════════════════════════════════
# SCHEMA VALIDATION (129 Fields - Locked per Use Case Doc)
# ═══════════════════════════════════════════════════════════════════════════════════════
REQUIRED_SCHEMA_SECTIONS = {
    "mongodb_metadata": ["_id", "mongo_tag", "data_source", "market", "record_version", "record_created_at", "record_updated_at"],
    "core_license_data": ["license_number", "business_name", "dba_name", "business_type", "classifications"],
    "contact_info": ["contact_name", "contact_type", "contact_title", "phone_business"],
    "address": ["address_street", "address_city", "address_state", "address_county", "address_zip"],
    "license_status": ["status_primary", "status_secondary", "license_issue_date", "license_expiration_date", "license_reissue_date", "days_to_expiry"],
    "workers_comp": ["wc_coverage_type", "wc_insurance_company", "wc_policy_number", "wc_effective_date", "wc_expiration_date"],
    "bond_data": ["cb_surety_company", "cb_bond_number", "cb_amount", "db_surety_company", "db_bond_reason", "db_case_number"],
    "risk_scoring": ["risk_score", "risk_tier"],
    "segmentation_flags": ["seg_home_improvement", "seg_general_contractor", "seg_wc_exposure", "seg_license_expiring_90d", "seg_has_suspension", "seg_has_la_presence"],
    "law_impact_2026": ["law_ab1327_email_cancel", "law_sb517_subcontractor", "law_sb291_wc_penalties", "law_any_2026_impact"],
    "enrichment_status": ["enrich_status", "enrich_google_places_done", "enrich_osha_done", "enrich_permits_done", "enrich_craigslist_done", "enrich_osint_done", "enrich_court_records_done"],
    "primal_triggers_fear": ["trigger_fear_disaster_zone", "trigger_fear_ab1327_deadline", "trigger_fear_sb291_penalty", "trigger_fear_sb779_fine", "trigger_fear_nascla_sweep", "trigger_fear_ab1002_wage", "trigger_fear_osha_investigation", "trigger_fear_craigslist_violation"],
    "primal_triggers_envy": ["trigger_envy_competitor_permits", "trigger_envy_govt_contracts", "trigger_envy_market_position", "trigger_envy_sb517_compliance", "trigger_envy_la_expansion"],
    "primary_report_flags": ["report_license_suspension_alert", "report_2026_compliance_deadline", "report_wc_exposure_audit", "report_osha_risk", "report_craigslist_competitor", "report_competitor_permit_tracker", "report_govt_contract_intel", "report_subcontractor_verification", "report_market_position", "report_la_expansion"],
    "crm_tracking": ["crm_lead_status", "crm_last_contact_date", "crm_email_sent_count", "crm_email_opened", "crm_report_purchased", "crm_report_purchased_date", "crm_total_revenue", "crm_chatbot_session_count", "crm_conversion_funnel_stage"]
}


class SchemaViolationError(Exception):
    """Raised when DataFrame doesn't match locked Use Case Doc schema"""
    pass


def validate_schema_compliance(df):
    """Validate DataFrame against Use Case Doc schema (warning mode, not blocking)."""
    missing_fields = []
    for section, fields in REQUIRED_SCHEMA_SECTIONS.items():
        for field in fields:
            if field not in df.columns:
                missing_fields.append(f"{section}.{field}")
    
    if missing_fields:
        print(f"⚠️ Schema warning: {len(missing_fields)} fields missing from DataFrame")
        print(f"   Missing sections: {set(f.split('.')[0] for f in missing_fields[:10])}")
        return False
    
    print(f"✅ Schema validation passed: {len(df.columns)} columns")
    return True


def get_primary_report_for_prospect(row):
    """Determine which PRIMARY reports a prospect is eligible for (fear first)."""
    eligible = []
    
    # TIER 1: Fear reports (highest priority)
    for report in PRIMARY_REPORT_CATALOG["tier_1_fear"]:
        if row.get(report["trigger_field"], False):
            eligible.append({
                "id": report["id"],
                "name": report["name"],
                "price": report["price"],
                "priority": 1,
                "type": "fear"
            })
    
    # TIER 2-3: Envy reports
    for report in PRIMARY_REPORT_CATALOG["tier_2_envy"] + PRIMARY_REPORT_CATALOG["tier_3_premium"]:
        if row.get(report["trigger_field"], False):
            eligible.append({
                "id": report["id"],
                "name": report["name"],
                "price": report["price"],
                "priority": 2,
                "type": "envy"
            })
    
    # Sort by priority (fear first), then by price (highest first)
    eligible.sort(key=lambda x: (x["priority"], -x["price"]))
    return eligible


def get_recommended_bundle(row):
    """Recommend a bundle based on prospect's segment."""
    if row.get("seg_general_contractor", False):
        return REPORT_BUNDLES["elite"]
    elif row.get("law_any_2026_impact", False):
        return REPORT_BUNDLES["growth"]
    else:
        return REPORT_BUNDLES["starter"]


def get_all_primary_reports():
    """Return flat list of all PRIMARY reports."""
    reports = []
    for tier in ["tier_1_fear", "tier_2_envy", "tier_3_premium"]:
        reports.extend(PRIMARY_REPORT_CATALOG.get(tier, []))
    return reports


# Export
__all__ = [
    'PRIMARY_REPORT_CATALOG',
    'SECONDARY_REPORT_CATALOG',
    'REPORT_BUNDLES',
    'REQUIRED_SCHEMA_SECTIONS',
    'USE_CASE_DOC_VERSION',
    'USE_CASE_DOC_LOCKED',
    'SchemaViolationError',
    'validate_schema_compliance',
    'get_primary_report_for_prospect',
    'get_recommended_bundle',
    'get_all_primary_reports'
]
