


GOOGLE PLACES v1	✅ READY	places.googleapis.com/v1/places:searchText	deep_enrichment_pipeline.py:177	place_id, rating, reviews, website, phone
GOOGLE PLACES LEGACY	✅ READY	maps.googleapis.com/maps/api/place/textsearch	enrichment_pipeline_runner.py:72	name, address, geometry, types
GOOGLE FIND + DETAILS	✅ READY	findplacefromtext + place/details	v3_enhanced_enrichment.py:358	formatted_phone_number, website
OSHA DOL FATALITIES	✅ READY	api.dol.gov/V1/Safety/Fatalities	deep_enrichment_pipeline.py:210	fatality_records, establishment_match
OSHA ENFORCEDATA	✅ READY	enforcedata.dol.gov/api/osha_inspection	deep_enrichment_pipeline.py:222	inspection_count, violation_count, penalty_total
ARCGIS SACRAMENTO	✅ READY	services.arcgis.com/.../Building_Permits	deep_enrichment_pipeline.py:240	permit_type, valuation, contractor_match
WAYBACK MACHINE CDX	✅ READY	web.archive.org/cdx/search/cdx	ReconDon_Wayback_Discovery.py:19	historical_snapshots, timestamp, original_url
DNS/MX VALIDATION	✅ READY	dnspython real DNS queries	deep_enrichment_pipeline.py:84	mx_records, dns_score, record_types
DNS FOOTPRINT	✅ READY	A, MX, TXT, NS record analysis	deep_enrichment_pipeline.py:106	digital_sophistication_score (0-100)
PHONE OSINT	✅ READY	phonenumbers library	deep_enrichment_pipeline.py:126	carrier, region, timezone, line_type, is_voip
RECONDON CRAIGSLIST	✅ READY	Async web scraping	deep_enrichment_pipeline.py:274	license_presence, violation_patterns, contact_info
RECONDON TARGETED SWEEP	✅ READY	SQLite + RabbitMQ integration	ReconDon_Targeted_Sweep.py:19	multi_vector_search, historical_timeline
DUCKDUCKGO DORKING	✅ READY	HTML scraping (no API key)	deep_enrichment_pipeline.py:337	court_records, yelp_presence, bbb_rating
RABBITMQ QUEUE	✅ READY	Pika/RabbitMQ messaging	ReconDon_Targeted_Sweep.py:19	cslb_enrichment queue, durable messaging
PARCEL ENRICHMENT	📍 LOCATE	PyCharm Projects location	parcel_enrich.py	property_data, assessor_reco