Offline development setup for Azure/Foundry-style workflows

Overview
- Run a lightweight local model mock service for development and testing.
- Use the `LocalMockAdapter` in `src/ai_adapter.py` to decouple your code from remote model calls.
- Use `docker-compose` in `.devcontainer/docker-compose.yml` to run the mock server: it exposes `http://localhost:5001/v1/generate`.

Quick start
1. Ensure Docker Desktop is running.
2. From workspace root, start the mock model server:

```powershell
docker compose -f .devcontainer/docker-compose.yml up --build -d
```

3. In Python, use the adapter:

```python
from src.ai_adapter import LocalMockAdapter
adapter = LocalMockAdapter()
print(adapter.predict('hello world'))
```

4. To stop the mock server:

```powershell
docker compose -f .devcontainer/docker-compose.yml down
```

Notes
- For deterministic unit tests, use the fixture returned by `LocalMockAdapter` when the server is unavailable.
- When online and integrating with Microsoft Foundry or Azure OpenAI, implement a `FoundryAdapter` that implements the same interface and swap via config/env.
