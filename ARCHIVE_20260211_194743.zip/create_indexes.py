#!/usr/bin/env python3
"""Create helpful indexes on the enrichment DB to speed queries and subsequent runs."""
import sqlite3
from pathlib import Path

DB = Path("./outputs/ferengi_enrichment.db")
if not DB.exists():
    print("DB not found:", DB)
    raise SystemExit(1)

conn = sqlite3.connect(DB)
cur = conn.cursor()
indexes = [
    ("idx_enrich_status", "enrich_status"),
    ("idx_license_number", "license_number"),
    ("idx_trigger_osha", "trigger_fear_osha_investigation"),
    ("idx_gp_place_id", "gp_place_id")
]
for name, col in indexes:
    try:
        cur.execute(f"CREATE INDEX IF NOT EXISTS {name} ON contractors({col})")
        print("Created index", name)
    except Exception as e:
        print("Failed to create", name, e)

conn.commit()
conn.close()

print("Indexes applied.")
